import { Injectable } from '@angular/core';
import { LanguageModel } from './language.model';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LanguageService {
  private readonly API_URL = 'http://localhost:5177/api/languages';

  constructor(private http: HttpClient) { }

  getLanguages(): Observable<LanguageModel[]> {
    return this.http.get<LanguageModel[]>(this.API_URL);
  }
}
