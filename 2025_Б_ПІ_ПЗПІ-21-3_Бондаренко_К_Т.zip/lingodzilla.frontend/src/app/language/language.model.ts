export interface LanguageModel {
  id: string;
  name: string;
  code: string;
}
