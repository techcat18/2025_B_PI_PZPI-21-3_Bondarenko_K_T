import { Component } from '@angular/core';
import { CourseService } from '../course.service';
import { CourseModel } from '../course.model';
import { ActivatedRoute, Router } from '@angular/router';
import { LessonModel } from '../../lesson/lesson.model';
import { LessonService } from '../../lesson/lesson.service';
import { AuthService } from '../../auth/auth.service';
import { CreateLessonComponent } from '../../lesson/create-lesson/create-lesson.component';
import { Dialog } from '@angular/cdk/dialog';
import { UpdateLessonComponent } from '../../lesson/update-lesson/update-lesson.component';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrl: './course.component.scss'
})
export class CourseComponent {
  course!: CourseModel;
  lessons: LessonModel[] = [];
  currentUserId: string = '';

  constructor(
    private route: ActivatedRoute,
    private courseService: CourseService,
    private lessonService: LessonService,
    private authService: AuthService,
    private router: Router,
    private dialog: Dialog
  ) {}

  ngOnInit(): void {
    const courseId = this.route.snapshot.paramMap.get('id');
    this.authService.getCurrentUser().subscribe({
      next: data => this.currentUserId = data.id
    });
    if (courseId) {
      this.courseService.getCourseById(courseId).subscribe({
        next: course => (this.course = course),
        error: err => console.error('Failed to load course', err)
      });
      this.getLessonsByCourseId(courseId);
    }
  }

  getLessonsByCourseId(id: string){
    this.lessonService.getLessonsByCourse(id).subscribe({
      next: lessons => (this.lessons = lessons),
      error: err => console.error('Failed to load lessons', err)
    });
  }

  goToLesson(lessonId: string): void {
    this.router.navigate(['/lessons', lessonId]);
  }

  openAddLesson() {
    const dialogRef = this.dialog.open(CreateLessonComponent, {
      data: {
        courseId: this.course.id,
        existingOrderIndexes: this.lessons.map(l => l.orderIndex)
      }
    });

    dialogRef.closed.subscribe({
      next: data => this.getLessonsByCourseId(this.course.id)
    })
  }

  openEditLesson(lesson: LessonModel) {
    const dialogRef = this.dialog.open(UpdateLessonComponent, {
      data: {
        lesson: lesson,
        existingOrderIndexes: this.lessons
          .filter(l => l.id !== lesson.id)
          .map(l => l.orderIndex)
      }
    });

    dialogRef.closed.subscribe({
      next: data => this.getLessonsByCourseId(this.course.id)
    })
  }

  deleteLesson(lesson: LessonModel) {
    if (confirm(`Are you sure you want to delete lesson "${lesson.name}"?`)) {
      this.lessonService.deleteLesson(lesson.id).subscribe({
        next: data => this.getLessonsByCourseId(this.course.id),
        error: err => console.error('Failed to delete a lesson', err)
      })
    }
  }
}
