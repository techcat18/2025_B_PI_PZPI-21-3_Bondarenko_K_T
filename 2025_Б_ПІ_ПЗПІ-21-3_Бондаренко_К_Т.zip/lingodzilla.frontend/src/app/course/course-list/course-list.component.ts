import { Component } from '@angular/core';
import { CourseModel } from '../course.model';
import { CourseService } from '../course.service';
import { Router } from '@angular/router';
import { LanguageModel } from '../../language/language.model';
import { LanguageService } from '../../language/language.service';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { CreateCourseComponent } from '../create-course/create-course.component';
import { Dialog } from '@angular/cdk/dialog';
import { UpdateCourseComponent } from '../update-course/update-course.component';
import { AuthService } from '../../auth/auth.service';

@Component({
  selector: 'app-course-list',
  templateUrl: './course-list.component.html',
  styleUrl: './course-list.component.scss'
})
export class CourseListComponent {
  courses: CourseModel[] = [];
  languages: LanguageModel[] = [];
  currentUserId: string = '';

  constructor(
    private courseService: CourseService,
    private languageService: LanguageService,
    private authService: AuthService,
    private router: Router,
    private dialog: Dialog
  ) {}

  ngOnInit(): void {
    this.authService.getCurrentUser().subscribe({
      next: data => this.currentUserId = data.id
    });
    this.getCourses();
    this.languageService.getLanguages().subscribe({
      next: data => this.languages = data,
      error: err => console.error('Failed to load languages', err)
    })
  }

  goToCourse(id: string): void {
    console.log('here')
    this.router.navigate(['/courses', id]);
  }

  getCourses(){
    this.courseService.getCourses().subscribe({
      next: data => this.courses = data,
      error: err => console.error('Failed to load courses', err)
    });
  }

  openCreateDialog(): void {
    const dialogRef = this.dialog.open(CreateCourseComponent);

    dialogRef.closed.subscribe({
      next: data => this.getCourses()
    })
  }

  openEditDialog(course: any): void {
    const dialogRef = this.dialog.open(UpdateCourseComponent, {
      data: {
        course: course
      }
    });

    dialogRef.closed.subscribe({
      next: data => this.getCourses()
    })
  }

  deleteCourse(id: string): void {
    this.courseService.deleteCourse(id).subscribe({
      next: data => this.getCourses(),
      error: err => console.error(err)
    })
  }
}
