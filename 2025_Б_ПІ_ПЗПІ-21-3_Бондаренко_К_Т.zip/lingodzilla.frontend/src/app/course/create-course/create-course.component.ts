import { DIALOG_DATA, DialogRef } from '@angular/cdk/dialog';
import { Component, Inject } from '@angular/core';
import { CreateCourseModel } from '../course.model';
import { LanguageService } from '../../language/language.service';
import { LanguageModel } from '../../language/language.model';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-create-course',
  templateUrl: './create-course.component.html',
  styleUrl: './create-course.component.scss'
})
export class CreateCourseComponent {
  languages: LanguageModel[] = [];

  model: CreateCourseModel = {
    id: '',
    name: '',
    description: '',
    languageId: '',
    targetLanguageId: ''
  };

  constructor(
    public dialogRef: DialogRef<CreateCourseComponent>,
    private languageService: LanguageService,
    private courseService: CourseService
  ) {
    this.languageService.getLanguages().subscribe({
      next: data => this.languages = data,
      error: err => console.error('Failed to load languages', err)
    })
  }

  submit(): void {
    this.courseService.createCourse(this.model).subscribe({
      next: data => this.dialogRef.close(),
      error: err => console.error(err)
    })
  }

  cancel(): void {
    this.dialogRef.close();
  }

  get isTargetLanguageSameAsLanguage(): boolean {
    return this.model.languageId != null && this.model.targetLanguageId != null &&
          this.model.languageId === this.model.targetLanguageId;
  }
}
