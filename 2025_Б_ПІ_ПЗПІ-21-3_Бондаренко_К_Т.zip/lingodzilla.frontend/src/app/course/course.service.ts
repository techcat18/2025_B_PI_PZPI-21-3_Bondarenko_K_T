import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CourseModel, CreateCourseModel } from './course.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CourseService {
  private readonly API_URL = 'http://localhost:5177/api/courses';

  constructor(private http: HttpClient) {}

  getCourses(): Observable<CourseModel[]> {
    return this.http.get<CourseModel[]>(this.API_URL);
  }

  getCourseById(id: string): Observable<CourseModel> {
    return this.http.get<CourseModel>(`${this.API_URL}/${id}`);
  }

  createCourse(createCourseModel: CreateCourseModel): Observable<CourseModel> {
    return this.http.post<CourseModel>(`${this.API_URL}`, createCourseModel);
  }

  updateCourse(updateCourseComponent: CreateCourseModel): Observable<CourseModel> {
    return this.http.put<CourseModel>(`${this.API_URL}/${updateCourseComponent.id}`, updateCourseComponent);
  }

  deleteCourse(id: string) {
    return this.http.delete(`${this.API_URL}/${id}`);
  }
}
