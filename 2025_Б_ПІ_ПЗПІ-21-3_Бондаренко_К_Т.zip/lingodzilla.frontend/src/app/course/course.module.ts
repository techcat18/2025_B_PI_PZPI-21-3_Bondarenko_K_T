import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CourseComponent } from './course/course.component';
import { SharedModule } from '../shared/shared.module';
import { CourseListComponent } from './course-list/course-list.component';
import { CreateCourseComponent } from './create-course/create-course.component';
import { UpdateCourseComponent } from './update-course/update-course.component';

@NgModule({
  declarations: [
    CourseComponent,
    CourseListComponent,
    CreateCourseComponent,
    UpdateCourseComponent
  ],
  imports: [
    CommonModule,
    SharedModule
  ]
})
export class CourseModule { }
