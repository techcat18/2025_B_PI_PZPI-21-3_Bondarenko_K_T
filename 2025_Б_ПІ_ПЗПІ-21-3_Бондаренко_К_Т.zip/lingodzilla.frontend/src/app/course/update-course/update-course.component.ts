import { Component, Inject } from '@angular/core';
import { CourseModel, CreateCourseModel } from '../course.model';
import { LanguageModel } from '../../language/language.model';
import { DIALOG_DATA, DialogRef } from '@angular/cdk/dialog';
import { LanguageService } from '../../language/language.service';
import { CourseService } from '../course.service';

@Component({
  selector: 'app-update-course',
  templateUrl: './update-course.component.html',
  styleUrl: './update-course.component.scss'
})
export class UpdateCourseComponent {
  model: CreateCourseModel;
  languages: LanguageModel[] = [];

  constructor(
    public dialogRef: DialogRef<UpdateCourseComponent>,
    private languageService: LanguageService,
    private courseService: CourseService,
    @Inject(DIALOG_DATA) public data: any
  ) {
    this.languageService.getLanguages().subscribe({
      next: data => this.languages = data,
      error: err => console.error('Failed to load languages', err)
    })

    this.model = {
      id: data.course.id,
      name: data.course.name,
      description: data.course.description ?? '',
      languageId: data.course.language.id,
      targetLanguageId: data.course.targetLanguage.id,
    };
  }

  get isTargetLanguageSameAsLanguage(): boolean {
    return (
      this.model.languageId != null &&
      this.model.targetLanguageId != null &&
      this.model.languageId === this.model.targetLanguageId
    );
  }

  submit(): void {
    this.courseService.updateCourse(this.model).subscribe({
      next: data => this.dialogRef.close(),
      error: err => console.error(err)
    })
  }

  cancel(): void {
    this.dialogRef.close();
  }
}
