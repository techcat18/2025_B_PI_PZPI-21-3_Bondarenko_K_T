import { LanguageModel } from "../language/language.model";
import { UserModel } from "../profile/user.model";

export interface CourseModel {
  id: string;
  name: string;
  description?: string;
  language: LanguageModel;
  targetLanguage: LanguageModel;
  user?: UserModel;
}

export interface CreateCourseModel{
  id: string;
  name: string;
  description: string;
  languageId: string;
  targetLanguageId: string;
}
