import { Pipe, PipeTransform } from '@angular/core';
import { LessonModel } from '../lesson/lesson.model';

@Pipe({
  name: 'orderByOrderIndex'
})
export class OrderByOrderIndexPipe implements PipeTransform {
  transform(lessons: LessonModel[]): LessonModel[] {
    return [...lessons].sort((a, b) => a.orderIndex - b.orderIndex);
  }
}
