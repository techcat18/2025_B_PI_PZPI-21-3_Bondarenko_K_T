import { Component, Inject } from '@angular/core';
import { UserModel } from '../../profile/user.model';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { UserService } from '../user.service';
import { FriendRequestModel } from '../../profile/friendRequest.model';

@Component({
  selector: 'app-user-selector-dialog',
  templateUrl: './user-selector-dialog.component.html',
  styleUrl: './user-selector-dialog.component.scss'
})
export class UserSelectorDialogComponent {
  users: UserModel[] = [];

  constructor(
    private dialogRef: MatDialogRef<UserSelectorDialogComponent>,
    private userService: UserService,
    @Inject(MAT_DIALOG_DATA) public data: {
      currentUserId: string,
      friends: UserModel[],
      friendRequests: FriendRequestModel[]
    }
  ) {}

  ngOnInit(): void {
    const excludedIds = new Set([
      this.data.currentUserId,
      ...this.data.friends.map(f => f.id),
      ...this.data.friendRequests.map(r => r.requester.id === this.data.currentUserId ? r.requester.id : r.addressee.id)
    ]);

    this.userService.getAllUsers().subscribe(users => {
      this.users = users.filter(u => !excludedIds.has(u.id));
    });
  }

  select(user: UserModel): void {
    this.dialogRef.close(user);
  }

  close(): void {
    this.dialogRef.close();
  }
}
