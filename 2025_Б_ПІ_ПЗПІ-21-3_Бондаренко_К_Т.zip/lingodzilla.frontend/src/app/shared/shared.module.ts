import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogModule } from '@angular/material/dialog';
import { MatListModule } from '@angular/material/list'
import { MatCheckboxModule } from '@angular/material/checkbox';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { NavbarComponent } from './navbar/navbar.component';
import { UserSelectorDialogComponent } from './user-selector-dialog/user-selector-dialog.component';
import { OrderByOrderIndexPipe } from './order-by-order-index.pipe';

@NgModule({
  declarations: [
    NavbarComponent,
    UserSelectorDialogComponent,
    OrderByOrderIndexPipe
  ],
  imports: [
    CommonModule,
    RouterModule,
    MatButtonModule,
    MatDialogModule,
    MatListModule
  ],
  exports: [
    CommonModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatInputModule,
    MatButtonModule,
    MatCardModule,
    MatIconModule,
    MatDialogModule,
    MatListModule,
    MatCheckboxModule,
    RouterModule,
    HttpClientModule,
    NavbarComponent,
    UserSelectorDialogComponent,
    OrderByOrderIndexPipe,
    FormsModule
  ]
})
export class SharedModule { }
