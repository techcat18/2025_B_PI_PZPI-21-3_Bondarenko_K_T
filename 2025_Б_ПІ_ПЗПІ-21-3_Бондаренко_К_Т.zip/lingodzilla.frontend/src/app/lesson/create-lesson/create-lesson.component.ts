import { DialogRef, DIALOG_DATA } from '@angular/cdk/dialog';
import { Component, Inject } from '@angular/core';
import { CreateLessonModel } from '../lesson.model';
import { LessonService } from '../lesson.service';

@Component({
  selector: 'app-create-lesson',
  templateUrl: './create-lesson.component.html',
  styleUrl: './create-lesson.component.scss'
})
export class CreateLessonComponent {
  model: CreateLessonModel = {
    id: '',
    name: '',
    orderIndex: 1,
    courseId: ''
  };

  existingOrderIndexes: number[] = [];
  orderConflict: boolean = false;

  constructor(
    public dialogRef: DialogRef<CreateLessonComponent>,
    private lessonService: LessonService,
    @Inject(DIALOG_DATA) public data: { courseId: string, existingOrderIndexes: number[] }
  ) {
    this.model.courseId = data.courseId;
    this.existingOrderIndexes = data.existingOrderIndexes;
  }

  submit(): void {
    this.orderConflict = this.existingOrderIndexes.includes(this.model.orderIndex);

    if (this.orderConflict) return;

    this.lessonService.createLesson(this.model).subscribe({
      next: () => this.dialogRef.close(),
      error: (err) => console.error(err)
    });
  }

  cancel(): void {
    this.dialogRef.close();
  }
}
