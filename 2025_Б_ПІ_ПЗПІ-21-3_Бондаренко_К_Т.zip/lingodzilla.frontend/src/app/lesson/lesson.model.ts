export interface LessonModel {
  id: string;
  name: string;
  orderIndex: number;
  courseId: string;
}

export interface CreateLessonModel {
  id: string;
  name: string;
  orderIndex: number;
  courseId: string;
}
