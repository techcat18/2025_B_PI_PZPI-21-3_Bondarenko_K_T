import { DialogRef, DIALOG_DATA } from '@angular/cdk/dialog';
import { Component, Inject } from '@angular/core';
import { CreateLessonModel } from '../lesson.model';
import { LessonService } from '../lesson.service';

@Component({
  selector: 'app-update-lesson',
  templateUrl: './update-lesson.component.html',
  styleUrl: './update-lesson.component.scss'
})
export class UpdateLessonComponent {
  model: CreateLessonModel;
  existingOrderIndexes: number[] = [];
  orderConflict: boolean = false;

  constructor(
    public dialogRef: DialogRef<UpdateLessonComponent>,
    private lessonService: LessonService,
    @Inject(DIALOG_DATA) public data: { lesson: CreateLessonModel, existingOrderIndexes: number[] }
  ) {
    this.model = data.lesson;
    this.existingOrderIndexes = data.existingOrderIndexes;
    console.log(this.existingOrderIndexes)
  }

  submit(): void {
    this.orderConflict = this.existingOrderIndexes.includes(this.model.orderIndex);
    if (this.orderConflict) return;

    this.lessonService.updateLesson(this.model).subscribe({
      next: () => this.dialogRef.close(),
      error: err => console.error(err)
    });
  }

  cancel(): void {
    this.dialogRef.close();
  }
}
