import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LessonComponent } from './lesson/lesson.component';
import { SharedModule } from '../shared/shared.module';
import { ExerciseModule } from '../exercise/exercise.module';
import { CreateLessonComponent } from './create-lesson/create-lesson.component';
import { UpdateLessonComponent } from './update-lesson/update-lesson.component';

@NgModule({
  declarations: [
    LessonComponent,
    CreateLessonComponent,
    UpdateLessonComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    ExerciseModule
  ]
})
export class LessonModule { }
