import { Component } from '@angular/core';
import { ExerciseModel } from '../../exercise/exercise.model';
import { ActivatedRoute, Router } from '@angular/router';
import { LessonService } from '../lesson.service';
import { ExerciseService } from '../../exercise/exercise.service';
import { AuthService } from '../../auth/auth.service';
import { CourseService } from '../../course/course.service';
import { CourseModel } from '../../course/course.model';
import { Dialog } from '@angular/cdk/dialog';
import { CreateExerciseComponent } from '../../exercise/create-exercise/create-exercise.component';
import { UpdateExerciseComponent } from '../../exercise/update-exercise/update-exercise.component';

@Component({
  selector: 'app-lesson',
  templateUrl: './lesson.component.html',
  styleUrl: './lesson.component.scss'
})
export class LessonComponent {
  lessonId!: string;
  exercises: ExerciseModel[] = [];
  currentIndex = 0;
  started = false;
  currentUserId: string = '';
  course: CourseModel | null = null;

  constructor(
    private route: ActivatedRoute,
    private lessonService: LessonService,
    private exerciseService: ExerciseService,
    private authService: AuthService,
    private courseService: CourseService,
    private router: Router,
    private dialog: Dialog
  ) {}

  ngOnInit(): void {
    this.lessonId = this.route.snapshot.paramMap.get('id')!;
    this.lessonService.getLessonById(this.lessonId).subscribe({
      next: data => {
        this.courseService.getCourseById(data.courseId).subscribe({
        next: course => {
          this.course = course;
          this.authService.getCurrentUser().subscribe({
          next: data => {
            this.currentUserId = data.id;
            if (this.course?.user?.id != this.currentUserId){
              this.started = true;
            }
          }
        });
        },
        error: err => console.error('Failed to load course', err)
      });
      }
    })
    this.reloadExercises();
  }

  get currentExercise(): ExerciseModel | undefined {
    return this.exercises[this.currentIndex];
  }

  next() {
    if (this.currentIndex < this.exercises.length - 1) {
      this.currentIndex++;
    }
    else{
      this.started = false;
      this.router.navigate(['/lessons', this.lessonId]);
    }
  }

  previous() {
    if (this.currentIndex > 0) {
      this.currentIndex--;
    }
  }

  start(): void {
    this.started = true;
  }

  openAddExercise(): void {
    const dialogRef = this.dialog.open(CreateExerciseComponent, {
      data: { lessonId: this.lessonId }
    });

    dialogRef.closed.subscribe(() => this.reloadExercises());
  }

  openEditExercise(exercise: ExerciseModel): void {
    const dialogRef = this.dialog.open(UpdateExerciseComponent, {
      data: { exercise: exercise }
    });

    dialogRef.closed.subscribe(() => this.reloadExercises());
  }

  deleteExercise(exercise: ExerciseModel): void {
    this.exerciseService.deleteExercise(exercise.id).subscribe({
      next: () => this.reloadExercises(),
      error: err => console.error('Failed to delete exercise', err)
    });
  }

  startFrom(index: number): void {
    this.currentIndex = index;
    this.started = true;
  }

  reloadExercises(): void {
    this.exerciseService.getExercisesByLesson(this.lessonId).subscribe({
      next: exs => this.exercises = exs,
      error: err => console.error('Failed to reload exercises', err)
    });
  }
}
