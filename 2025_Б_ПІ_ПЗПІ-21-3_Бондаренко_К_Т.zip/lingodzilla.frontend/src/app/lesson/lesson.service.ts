import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CreateLessonModel, LessonModel } from './lesson.model';

@Injectable({
  providedIn: 'root'
})
export class LessonService {
  private readonly API_URL = 'http://localhost:5177/api/courses';
  private readonly LESSON_API_URL = 'http://localhost:5177/api/lessons';

  constructor(private http: HttpClient) {}

  getLessonsByCourse(courseId: string): Observable<LessonModel[]> {
    return this.http.get<LessonModel[]>(`${this.API_URL}/${courseId}/lessons`);
  }

  getLessonById(id: string): Observable<LessonModel>{
    return this.http.get<LessonModel>(`${this.LESSON_API_URL}/${id}`);
  }

  createLesson(createLessonModel: CreateLessonModel): Observable<LessonModel>{
    return this.http.post<LessonModel>(`${this.LESSON_API_URL}`, createLessonModel);
  }

  updateLesson(updateLessonModel: CreateLessonModel): Observable<LessonModel>{
    return this.http.put<LessonModel>(`${this.LESSON_API_URL}/${updateLessonModel.id}`, updateLessonModel);
  }

  deleteLesson(id: string) {
    return this.http.delete(`${this.LESSON_API_URL}/${id}`);
  }
}
