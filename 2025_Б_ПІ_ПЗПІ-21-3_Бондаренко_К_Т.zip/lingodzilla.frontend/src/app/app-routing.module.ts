import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';
import { SignupComponent } from './auth/signup/signup.component';
import { ProfileComponent } from './profile/profile/profile.component';
import { CourseComponent } from './course/course/course.component';
import { CourseListComponent } from './course/course-list/course-list.component';
import { LessonComponent } from './lesson/lesson/lesson.component';
import { LeaderboardComponent } from './leaderboard/leaderboard/leaderboard.component';
import { FlashcardsComponent } from './flashcards/flashcards/flashcards.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'profile', component: ProfileComponent },
  { path: 'courses', component: CourseListComponent },
  { path: 'courses/:id', component: CourseComponent },
  { path: 'lessons/:id', component: LessonComponent },
  { path: 'leaderboard', component: LeaderboardComponent },
  { path: 'flashcards', component: FlashcardsComponent },
  { path: '', redirectTo: '/login', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
