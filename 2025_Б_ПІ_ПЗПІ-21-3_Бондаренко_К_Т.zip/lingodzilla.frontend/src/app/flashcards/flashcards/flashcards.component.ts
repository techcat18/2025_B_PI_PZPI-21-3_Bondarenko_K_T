import { Component } from '@angular/core';
import { CreateFlashcardModel, FlashcardModel } from '../flashcard.model';
import { FlashcardService } from '../flashcard.service';

@Component({
  selector: 'app-flashcards',
  templateUrl: './flashcards.component.html',
  styleUrl: './flashcards.component.scss'
})
export class FlashcardsComponent {
  flashcards: FlashcardModel[] = [];
  filteredFlashcards: FlashcardModel[] = [];
  currentFlashcards: FlashcardModel[] = [];
  currentIndex = 0;
  showBack = false;
  isGameStarted = false;
  gameStarted = false;
  flashcardsToShow: number = 0;
  searchQuery: string = '';
  isCreateFormVisible = false;
  searchTerm: string = '';
  showActiveOnly: boolean | null = null;

  newFlashcard = {
    id: '',
    text: '',
    translation: '',
    partOfSpeech: '',
    exampleSentence: ''
  };

  constructor(private flashcardService: FlashcardService) {}

  ngOnInit(): void {
    this.getFlashcards();
  }

  getFlashcards(){
    this.flashcardService.getFlashcards(this.searchTerm, this.showActiveOnly).subscribe(cards => {
      this.flashcards = cards;
      this.filteredFlashcards = cards;
    });
  }

  toggleCreateForm(): void {
    this.isCreateFormVisible = !this.isCreateFormVisible;
  }

  searchFlashcards(): void {
    const query = this.searchQuery.toLowerCase();
    this.filteredFlashcards = this.flashcards.filter(flashcard =>
      flashcard.word.text.toLowerCase().includes(query)
    );
  }

  toggleActive(flashcard: FlashcardModel): void {
    flashcard.isActive = !flashcard.isActive;
    this.flashcardService.updateFlashcard(flashcard).subscribe(updatedFlashcard => {
      const index = this.flashcards.findIndex(f => f.id === updatedFlashcard.id);
      if (index !== -1) {
        this.flashcards[index] = updatedFlashcard;
        this.getFlashcards();
      }
    });
  }

  createFlashcard(): void {
    this.flashcardService.createFlashcard(this.newFlashcard).subscribe(newCard => {
      this.flashcards.push(newCard);
      this.getFlashcards();
      this.isCreateFormVisible = false;
    });
  }

  onFileSelected(event: any): void {
    const file: File = event.target.files[0];
    if (file) {
      this.importFlashcards(file);
    }
  }

  importFlashcards(file: File): void {
    this.flashcardService.importFlashcards(file).subscribe({
      next: (response) => {
        this.getFlashcards();
        this.isCreateFormVisible = false;
      },
      error: (err) => {
        console.error('Error importing flashcards:', err);
        alert('Failed to import flashcards');
      }
    });
  }

  startFlashcardGame(): void {
    this.isGameStarted = true;
    this.gameStarted = false;
  }

  startGame(): void {
    const activeFlashcards = this.filteredFlashcards;

    this.currentFlashcards = this.getRandomFlashcards(activeFlashcards, this.flashcardsToShow);
    this.currentIndex = 0;
    this.gameStarted = true;
    console.log('Flashcards: ', this.currentFlashcards)
  }

  stopGame(): void {
    this.isGameStarted = false;
    this.gameStarted = false;
    this.currentFlashcards = [];
    this.currentIndex = 0;
  }

  getRandomFlashcards(flashcards: FlashcardModel[], number: number): FlashcardModel[] {
    const shuffled = [...flashcards].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, number);
  }

  flipCard(): void {
    this.showBack = !this.showBack;
  }

  nextCard(): void {
    if (this.currentIndex < this.currentFlashcards.length - 1) {
      this.currentIndex++;
      this.showBack = false;
    }
  }

  prevCard(): void {
    if (this.currentIndex > 0) {
      this.currentIndex--;
      this.showBack = false;
    }
  }
}
