import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { CreateFlashcardModel, FlashcardModel } from './flashcard.model';

@Injectable({
  providedIn: 'root'
})
export class FlashcardService {
  private readonly API_URL = 'http://localhost:5177/api/flashcards';

  constructor(private http: HttpClient) {}

  getFlashcards(
    search: string = '',
    isActive: boolean | null = null
  ): Observable<FlashcardModel[]> {
    let params = new HttpParams()
      .set('searchQuery', search);

    if (isActive !== null) {
      params = params.set('isActive', isActive.toString());
    }

    return this.http.get<FlashcardModel[]>(this.API_URL, { params });
  }

  createFlashcard(createFlashcardModel: CreateFlashcardModel) : Observable<FlashcardModel>{
    return this.http.post<FlashcardModel>(`${this.API_URL}`, createFlashcardModel);
  }

  updateFlashcard(flashcard: FlashcardModel) : Observable<FlashcardModel>{
    return this.http.put<FlashcardModel>(`${this.API_URL}/${flashcard.id}`, flashcard);
  }

  deleteFlashcard(id: string) : Observable<any>{
    return this.http.delete<any>(`${this.API_URL}/${id}`);
  }

  importFlashcards(csvFile: File): Observable<any> {
    const formData = new FormData();
    formData.append('file', csvFile, csvFile.name);

    return this.http.post(`${this.API_URL}/import`, formData);
  }
}
