import { Component } from '@angular/core';
import { UserModel } from '../user.model';
import { AuthService } from '../../auth/auth.service';
import { FriendRequestModel } from '../friendRequest.model';
import { FriendService } from '../friend.service';
import { MatDialog } from '@angular/material/dialog';
import { UserSelectorDialogComponent } from '../../shared/user-selector-dialog/user-selector-dialog.component';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrl: './profile.component.scss'
})
export class ProfileComponent {
  user!: UserModel;
  friends: UserModel[] = [];
  friendRequests: FriendRequestModel[] = [];
  potentialFriendEmail = '';

  constructor(
    private authService: AuthService,
    private friendService: FriendService,
    private dialog: MatDialog) {}

  ngOnInit(): void {
    this.authService.getCurrentUser().subscribe({
      next: user => {
        this.user = user;
      },
      error: err => {
        console.error('Failed to load user profile:', err);
      }
    });
    this.loadFriends();
    this.loadFriendRequests();
  }

  defaultAvatar = '/images/default-avatar.png';

  onAvatarSelected(event: Event): void {
    const fileInput = event.target as HTMLInputElement;
    if (fileInput.files && fileInput.files.length > 0) {
      const file = fileInput.files[0];
      const reader = new FileReader();
      reader.onload = () => {
        this.user.avatar = reader.result as string;
      };
      reader.readAsDataURL(file);
    }
  }

  loadFriends(): void {
    this.friendService.getFriends().subscribe({
      next: friends => (this.friends = friends),
      error: err => console.error('Error loading friends', err)
    });
  }

  loadFriendRequests(): void {
    this.friendService.getFriendRequests().subscribe({
      next: requests => (this.friendRequests = requests),
      error: err => console.error('Error loading requests', err)
    });
  }

  sendRequest(): void {
    const dialogRef = this.dialog.open(UserSelectorDialogComponent, {
      width: '600px',
      maxHeight: '80vh',
      data: {
        currentUserId: this.user.id,
        friends: this.friends,
        friendRequests: this.friendRequests
       }
    });

    dialogRef.afterClosed().subscribe((selectedUser: UserModel) => {
      if (selectedUser) {
        this.friendService.sendRequest(selectedUser.id).subscribe(() => {
          alert('Friend request sent!');
        });
      }
    });
  }

  respondToRequest(request: FriendRequestModel, accept: boolean): void {
    this.friendService.respondToRequest(request.id, accept).subscribe({
      next: () => {
        this.loadFriends();
        this.loadFriendRequests();
      },
      error: err => alert('Failed to respond: ' + err.message)
    });
  }

  update(): void {
    this.authService.updateUser(this.user).subscribe({
      next: () => alert('User updated.'),
      error: err => alert('Failed to update user: ' + err.message)
    });
  }
}
