import { Injectable } from '@angular/core';
import { UserModel } from './user.model';
import { FriendRequestModel } from './friendRequest.model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FriendService {
  private readonly API_URL = 'http://localhost:5177/api/friends';

  constructor(private http: HttpClient) {}

  getFriends(): Observable<UserModel[]> {
    return this.http.get<UserModel[]>(`${this.API_URL}`);
  }

  getFriendRequests(): Observable<FriendRequestModel[]> {
    return this.http.get<FriendRequestModel[]>(`${this.API_URL}/requests`);
  }

  sendRequest(toUserId: string): Observable<void> {
    return this.http.post<void>(`${this.API_URL}/requests/send`, { "toUserId": toUserId });
  }

  respondToRequest(requestId: string, accept: boolean): Observable<void> {
    return this.http.put<void>(`${this.API_URL}/requests/respond/${requestId}`, { "accepted": accept });
  }
}
