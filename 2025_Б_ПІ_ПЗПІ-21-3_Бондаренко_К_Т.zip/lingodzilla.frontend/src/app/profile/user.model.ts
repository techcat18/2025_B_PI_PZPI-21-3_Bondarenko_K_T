export interface UserModel {
  id: string,
  email: string;
  userName: string;
  avatar?: string;
  phoneNumber?: string;
  sendReminders: boolean;
}
