import { UserModel } from "./user.model";

export interface FriendRequestModel {
  id: string;
  requester: UserModel;
  addressee: UserModel;
  status: 'Pending' | 'Accepted' | 'Declined';
  requestedAt: string;
  respondedAt?: string;
}
