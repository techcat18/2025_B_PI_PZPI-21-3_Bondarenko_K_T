import { Injectable } from '@angular/core';
import { LoginModel, SignupModel } from './auth.model';
import { Observable, BehaviorSubject, tap } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { UserModel } from '../profile/user.model';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private readonly API_URL = 'http://localhost:5177/api/auth';

  private isAuthenticatedSubject = new BehaviorSubject<boolean>(this.isAuthenticated());
  public isAuthenticated$ = this.isAuthenticatedSubject.asObservable();

  constructor(private http: HttpClient) {}

  login(dto: LoginModel): Observable<any> {
    return this.http.post(`${this.API_URL}/login`, dto).pipe(
      tap((res: any) => {
        if (res.token) {
          localStorage.setItem('token', res.token);
          this.isAuthenticatedSubject.next(true);
        }
      })
    );
  }

  signup(dto: SignupModel): Observable<any> {
    return this.http.post(`${this.API_URL}/signup`, dto);
  }

  logout(): void {
    localStorage.removeItem('token');
    this.isAuthenticatedSubject.next(false);
  }

  isAuthenticated(): boolean {
    const token = localStorage.getItem('token');
    if (!token) return false;

    const payload = this.getPayload(token);
    if (!payload) return false;

    const exp = payload.exp;
    return Date.now() < exp * 1000;
  }

  getToken(): string | null {
    return localStorage.getItem('token');
  }

  getCurrentUser(): Observable<UserModel> {
    return this.http.get<UserModel>(`${this.API_URL}/me`);
  }

  updateUser(user: UserModel): Observable<UserModel> {
    return this.http.put<UserModel>(`${this.API_URL}/me`, user);
  }

  private getPayload(token: string): any | null {
    try {
      const payloadBase64 = token.split('.')[1];
      const decodedPayload = atob(payloadBase64);
      return JSON.parse(decodedPayload);
    } catch {
      return null;
    }
  }
}
