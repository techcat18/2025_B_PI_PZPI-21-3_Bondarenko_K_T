export interface LoginModel {
  email: string;
  password: string;
}

export interface SignupModel {
  email: string;
  userName: string;
  password: string;
}
