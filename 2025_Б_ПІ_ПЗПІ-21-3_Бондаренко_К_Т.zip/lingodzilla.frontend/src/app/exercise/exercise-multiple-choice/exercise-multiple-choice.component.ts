import { Component, EventEmitter, Input, Output } from '@angular/core';
import { DoExerciseModel, ExerciseModel } from '../exercise.model';
import { ExerciseService } from '../exercise.service';

@Component({
  selector: 'app-exercise-multiple-choice',
  templateUrl: './exercise-multiple-choice.component.html',
  styleUrl: './exercise-multiple-choice.component.scss'
})
export class ExerciseMultipleChoiceComponent {
  @Input() exercise!: ExerciseModel;
  @Output() next = new EventEmitter<void>();

  userAnswer: string = '';
  isSubmitted = false;
  isCorrect = false;
  showFeedback = false;

  constructor(private exerciseService: ExerciseService) {}

  submitAnswer() {
    this.isSubmitted = true;

    const model: DoExerciseModel = {
      submittedAnswer: this.userAnswer
    };

    this.exerciseService.submitExerciseAnswer(this.exercise.id, model).subscribe({
      next: (result) => {
        this.isCorrect = result;
        this.showFeedback = true;
      },
      error: err => console.error('Submission failed', err)
    });
  }

  goToNext() {
    this.userAnswer = '';
    this.isSubmitted = false;
    this.showFeedback = false;
    this.isCorrect = false;

    this.next.emit();
  }
}
