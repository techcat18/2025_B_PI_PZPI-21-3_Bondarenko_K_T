import { Component, EventEmitter, Inject, Output } from '@angular/core';
import { CreateExerciseModel, ExerciseModel, ExerciseTypeModel } from '../exercise.model';
import { ExerciseService } from '../exercise.service';
import { DIALOG_DATA, DialogRef } from '@angular/cdk/dialog';

@Component({
  selector: 'app-create-exercise',
  templateUrl: './create-exercise.component.html',
  styleUrl: './create-exercise.component.scss'
})
export class CreateExerciseComponent {
  @Output() created = new EventEmitter<ExerciseModel>();

  exerciseTypes: ExerciseTypeModel[] = [];

  model: CreateExerciseModel = {
    id: '',
    question: '',
    audioUrl: '',
    correctAnswer: '',
    explanation: '',
    exerciseTypeId: this.exerciseTypes[0]?.id,
    lessonId: '',
    words: [],
    options: []
  };

  showWordsSection = false;
  showOptionsSection = false;
  showAudioUrl = false;

  constructor(
    public dialogRef: DialogRef<CreateExerciseComponent>,
    private exerciseService: ExerciseService,
    @Inject(DIALOG_DATA) public data: {lessonId: string}
  ) {
    this.model.lessonId = data.lessonId;
  }

  ngOnInit(): void {
    this.getExerciseTypes();
  }

  onExerciseTypeChange() {
    this.showWordsSection = false;
    this.showOptionsSection = false;
    this.showAudioUrl = false;
    let exerciseType = this.exerciseTypes.filter(x => x.id == this.model.exerciseTypeId)[0];
    if (exerciseType.name === 'Fill in the Blank'){
      this.showWordsSection = true;
    }
    else if (exerciseType.name === 'Multiple Choice'){
      this.showOptionsSection = true;
    }
    else if (exerciseType.name === 'Listening Comprehension'){
      this.showAudioUrl = true;
    }
  }

  getExerciseTypes(){
    this.exerciseService.getExerciseTypes().subscribe({
      next: data => this.exerciseTypes = data
    })
  }

  addWord() {
    this.model.words.push({
      text: '',
      translation: '',
      partOfSpeech: '',
      exampleSentence: ''
    });
  }

  removeWord(index: number) {
    this.model.words.splice(index, 1);
  }

  addOption() {
    this.model.options.push({
      optionText: '',
      isCorrect: false
    });
  }

  removeOption(index: number) {
    this.model.options.splice(index, 1);
  }

  submit() {
    this.exerciseService.createExercise(this.model).subscribe({
      next: () => this.dialogRef.close(),
      error: err => console.error(err)
    })
  }

  cancel(): void {
    this.dialogRef.close();
  }
}
