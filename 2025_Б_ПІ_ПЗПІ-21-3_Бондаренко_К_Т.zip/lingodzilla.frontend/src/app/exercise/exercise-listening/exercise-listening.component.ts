import { Component, EventEmitter, Input, Output } from '@angular/core';
import { DoExerciseModel, ExerciseModel } from '../exercise.model';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { ExerciseService } from '../exercise.service';

@Component({
  selector: 'app-exercise-listening',
  templateUrl: './exercise-listening.component.html',
  styleUrl: './exercise-listening.component.scss'
})
export class ExerciseListeningComponent {
  @Input() exercise!: ExerciseModel;
  @Output() next = new EventEmitter<void>();

  userAnswer = '';
  isSubmitted = false;
  isCorrect = false;
  feedbackMessage = '';
  safeAudioUrl?: SafeResourceUrl;
  showFeedback = false;

  constructor(
    private sanitizer: DomSanitizer,
    private exerciseService: ExerciseService
  ) {}

  ngOnChanges() {
    if (this.exercise?.audioUrl) {
      this.safeAudioUrl = this.sanitizer.bypassSecurityTrustResourceUrl(this.exercise.audioUrl);
    }
  }

  submitAnswer() {
    this.isSubmitted = true;

    const model: DoExerciseModel = {
      submittedAnswer: this.userAnswer
    };

    this.exerciseService.submitExerciseAnswer(this.exercise.id, model).subscribe({
      next: (result) => {
        this.isCorrect = result;
        this.showFeedback = true;
      },
      error: err => console.error('Submission failed', err)
    });
  }

  goToNext() {
    this.userAnswer = '';
    this.isSubmitted = false;
    this.showFeedback = false;
    this.isCorrect = false;

    this.next.emit();
  }
}
