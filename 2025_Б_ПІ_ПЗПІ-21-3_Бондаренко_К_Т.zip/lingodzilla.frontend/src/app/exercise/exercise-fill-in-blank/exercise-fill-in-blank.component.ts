import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { DoExerciseModel, ExerciseModel } from '../exercise.model';
import { ExerciseService } from '../exercise.service';

@Component({
  selector: 'app-exercise-fill-in-blank',
  templateUrl: './exercise-fill-in-blank.component.html',
  styleUrl: './exercise-fill-in-blank.component.scss'
})
export class ExerciseFillInBlankComponent implements OnChanges {
  @Input() exercise!: ExerciseModel;
  @Output() next = new EventEmitter<void>();

  userAnswer = '';
  isSubmitted = false;
  isCorrect = false;
  questionParts: string[] = [];
  showFeedback = false;

  constructor(private exerciseService: ExerciseService) {}

  ngOnInit(): void {
    const question = this.exercise.question || '';
    this.questionParts = question.split(/(___)/);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['exercise'] && changes['exercise'].currentValue) {
      const question = changes['exercise'].currentValue.question || '';
      this.questionParts = question.split(/(___)/);
      this.resetState();
    }
  }

  submitAnswer() {
    this.isSubmitted = true;

    const model: DoExerciseModel = {
      submittedAnswer: this.userAnswer
    };

    this.exerciseService.submitExerciseAnswer(this.exercise.id, model).subscribe({
      next: (result) => {
        this.isCorrect = result;
        this.showFeedback = true;
      },
      error: err => console.error('Submission failed', err)
    });
  }

  selectWord(word: string): void {
    this.userAnswer = word;
  }

  goToNext() {
    this.resetState();

    this.next.emit();
  }

  private resetState() {
    this.userAnswer = '';
    this.isSubmitted = false;
    this.showFeedback = false;
    this.isCorrect = false;
  }
}
