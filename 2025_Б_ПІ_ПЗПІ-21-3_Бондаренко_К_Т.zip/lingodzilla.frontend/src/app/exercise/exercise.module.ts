import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ExerciseTranslationComponent } from './exercise-translation/exercise-translation.component';
import { SharedModule } from '../shared/shared.module';
import { ExerciseFillInBlankComponent } from './exercise-fill-in-blank/exercise-fill-in-blank.component';
import { ExerciseListeningComponent } from './exercise-listening/exercise-listening.component';
import { ExerciseMultipleChoiceComponent } from './exercise-multiple-choice/exercise-multiple-choice.component';
import { CreateExerciseComponent } from './create-exercise/create-exercise.component';
import { UpdateExerciseComponent } from './update-exercise/update-exercise.component';

@NgModule({
  declarations: [
    ExerciseTranslationComponent,
    ExerciseFillInBlankComponent,
    ExerciseListeningComponent,
    ExerciseMultipleChoiceComponent,
    CreateExerciseComponent,
    UpdateExerciseComponent
  ],
  imports: [
    CommonModule,
    SharedModule
  ],
  exports: [
    ExerciseTranslationComponent,
    ExerciseFillInBlankComponent,
    ExerciseListeningComponent,
    ExerciseMultipleChoiceComponent
  ]
})
export class ExerciseModule { }
