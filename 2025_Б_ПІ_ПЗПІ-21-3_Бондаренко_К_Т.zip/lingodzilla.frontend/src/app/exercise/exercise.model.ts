import { WordModel } from "../flashcards/flashcard.model";

export interface ExerciseTypeModel {
  id: string;
  name: string;
  description?: string | null;
}

export interface ExerciseModel {
  id: string;
  question: string;
  audioUrl?: string;
  correctAnswer: string;
  explanation?: string | null;
  exerciseType: ExerciseTypeModel;
  lessonId: string;
  words: WordModel[];
  options: ExerciseOptionModel[];
}

export interface CreateExerciseModel {
  id: string;
  question: string;
  audioUrl?: string;
  correctAnswer: string;
  explanation?: string | null;
  exerciseTypeId: string;
  lessonId: string;
  words: WordModel[];
  options: ExerciseOptionModel[];
}

export interface DoExerciseModel {
  submittedAnswer: string;
}

export interface ExerciseOptionModel {
  id?: string;
  optionText: string;
  isCorrect: boolean;
}
