import { DialogRef, DIALOG_DATA } from '@angular/cdk/dialog';
import { Component, Inject } from '@angular/core';
import { CreateExerciseModel, ExerciseModel, ExerciseTypeModel } from '../exercise.model';
import { ExerciseService } from '../exercise.service';

@Component({
  selector: 'app-update-exercise',
  templateUrl: './update-exercise.component.html',
  styleUrl: './update-exercise.component.scss'
})
export class UpdateExerciseComponent {
  model: any;
  exerciseTypes: ExerciseTypeModel[] = [];

  showWordsSection = false;
  showOptionsSection = false;
  showAudioUrl = false;

  constructor(
    public dialogRef: DialogRef<UpdateExerciseComponent>,
    private exerciseService: ExerciseService,
    @Inject(DIALOG_DATA) public data: { exercise: CreateExerciseModel }
  ) {
    this.model = data.exercise;
  }

  ngOnInit(): void {
    this.getExerciseTypes();
  }

  getExerciseTypes() {
    this.exerciseService.getExerciseTypes().subscribe({
      next: (data) => {
        this.exerciseTypes = data;
        this.onExerciseTypeChange();
      }
    });
  }

  onExerciseTypeChange() {
    const type = this.exerciseTypes.find(x => x.id === this.model.exerciseType.id);
    if (!type) return;

    this.showWordsSection = type.name === 'Fill in the Blank';
    this.showOptionsSection = type.name === 'Multiple Choice';
    this.showAudioUrl = type.name === 'Listening Comprehension';
    this.model.exerciseTypeId = type.id;
  }

  addWord() {
    this.model.words.push({
      text: '',
      translation: '',
      partOfSpeech: '',
      exampleSentence: ''
    });
  }

  removeWord(index: number) {
    this.model.words.splice(index, 1);
  }

  addOption() {
    this.model.options.push({
      optionText: '',
      isCorrect: false
    });
  }

  removeOption(index: number) {
    this.model.options.splice(index, 1);
  }

  submit() {
    this.exerciseService.updateExercise(this.model).subscribe({
      next: () => this.dialogRef.close(),
      error: err => console.error(err)
    });
  }

  cancel(): void {
    this.dialogRef.close();
  }
}
