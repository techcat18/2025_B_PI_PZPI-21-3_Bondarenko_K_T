import { Injectable } from '@angular/core';
import { CreateExerciseModel, DoExerciseModel, ExerciseModel, ExerciseTypeModel } from './exercise.model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ExerciseService {
  private readonly API_URL = 'http://localhost:5177/api/lessons';
  private readonly EXERCISES_API_URL = 'http://localhost:5177/api/exercises';

  constructor(private http: HttpClient) {}

  getExercisesByLesson(lessonId: string): Observable<ExerciseModel[]> {
    return this.http.get<ExerciseModel[]>(`${this.API_URL}/${lessonId}/exercises`);
  }

  getExerciseTypes(): Observable<ExerciseTypeModel[]> {
    return this.http.get<ExerciseTypeModel[]>(`${this.EXERCISES_API_URL}/types`);
  }

  submitExerciseAnswer(exerciseId: string, doExerciseModel: DoExerciseModel): Observable<any> {
    return this.http.post<any>(`${this.EXERCISES_API_URL}/${exerciseId}/do`, doExerciseModel);
  }

  createExercise(createExerciseModel: CreateExerciseModel): Observable<ExerciseModel> {
    return this.http.post<ExerciseModel>(`${this.EXERCISES_API_URL}`, createExerciseModel);
  }

  updateExercise(updateExerciseModel: CreateExerciseModel): Observable<ExerciseModel> {
    return this.http.put<ExerciseModel>(`${this.EXERCISES_API_URL}/${updateExerciseModel.id}`, updateExerciseModel);
  }

  deleteExercise(id: string){
    return this.http.delete(`${this.EXERCISES_API_URL}/${id}`);
  }
}
