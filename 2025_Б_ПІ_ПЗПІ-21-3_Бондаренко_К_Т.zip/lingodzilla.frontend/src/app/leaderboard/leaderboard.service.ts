import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { LeaderboardEntryModel } from './leaderboardEntry.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LeaderboardService {
  private readonly API_URL = 'http://localhost:5177/api/leaderboards';

  constructor(private http: HttpClient) {}

  getCompletedExercises(limit = 10): Observable<LeaderboardEntryModel[]> {
    return this.http.get<LeaderboardEntryModel[]>(`${this.API_URL}/completedExercises?limit=${limit}`);
  }

  getCorrectAnswers(limit = 10): Observable<LeaderboardEntryModel[]> {
    return this.http.get<LeaderboardEntryModel[]>(`${this.API_URL}/correctAnswers?limit=${limit}`);
  }

  getAccuracy(limit = 10): Observable<LeaderboardEntryModel[]> {
    return this.http.get<LeaderboardEntryModel[]>(`${this.API_URL}/accuracy?limit=${limit}`);
  }

  getCompletedLessons(limit = 10): Observable<LeaderboardEntryModel[]> {
    return this.http.get<LeaderboardEntryModel[]>(`${this.API_URL}/completedLessons?limit=${limit}`);
  }
}
