import { UserModel } from "../profile/user.model";

export interface LeaderboardEntryModel{
  user: UserModel;
  score: number;
}
