import { Component } from '@angular/core';
import { LeaderboardEntryModel } from '../leaderboardEntry.model';
import { LeaderboardService } from '../leaderboard.service';

@Component({
  selector: 'app-leaderboard',
  templateUrl: './leaderboard.component.html',
  styleUrl: './leaderboard.component.scss'
})
export class LeaderboardComponent {
  leaderboard: LeaderboardEntryModel[] = [];
  selectedMode = 'completedExercises';
  isLoading = false;

  constructor(private leaderboardService: LeaderboardService) {}

  ngOnInit(): void {
    this.loadLeaderboard();
  }

  loadLeaderboard(): void {
    this.isLoading = true;

    let request$;

    switch (this.selectedMode) {
      case 'correctAnswers':
        request$ = this.leaderboardService.getCorrectAnswers();
        break;
      case 'accuracy':
        request$ = this.leaderboardService.getAccuracy();
        break;
      case 'completedLessons':
        request$ = this.leaderboardService.getCompletedLessons();
        break;
      default:
        request$ = this.leaderboardService.getCompletedExercises();
    }

    request$.subscribe({
      next: data => {
        this.leaderboard = data;
        this.isLoading = false;
      },
      error: () => {
        this.isLoading = false;
      }
    });
  }

  onModeChange(): void {
    this.loadLeaderboard();
  }
}
