﻿using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Lingodzilla.Common.Constants;
using Lingodzilla.Flashcards.Persistence;
using Lingodzilla.Infrastructure.Authorization.Requirements;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.VisualBasic;

namespace Lingodzilla.Infrastructure.Authorization.Handlers;

public class PermissionAuthorizationHandler: AuthorizationHandler<PermissionRequirement>
{
    protected override Task HandleRequirementAsync(
        AuthorizationHandlerContext context, 
        PermissionRequirement requirement)
    {
        if (HasUserPermission(context, requirement))
        {
            context.Succeed(requirement);
            return Task.CompletedTask;
        }

        context.Fail();
        return Task.CompletedTask;
    }

    private static bool HasUserPermission(AuthorizationHandlerContext context, PermissionRequirement requirement)
    {
        if (context.User.Identity is null or { IsAuthenticated: false })
        {
            return false;
        }

        var userIdClaim = context.User.Claims.FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier);
        if (userIdClaim == null || !Guid.TryParse(userIdClaim.Value, out _))
        {
            return false;
        }

        var permissions = context.User.Claims
            .Where(x => x.Type == AuthClaimTypes.Permissions)
            .Select(x => x.Value)
            .ToList();

        return permissions.Any(x => x == requirement.Permission);
    }
}