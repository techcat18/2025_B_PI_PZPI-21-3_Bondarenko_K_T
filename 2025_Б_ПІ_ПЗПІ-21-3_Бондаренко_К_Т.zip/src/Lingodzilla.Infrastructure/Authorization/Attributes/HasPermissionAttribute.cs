﻿using Lingodzilla.Common.Constants;
using Microsoft.AspNetCore.Authorization;

namespace Lingodzilla.Infrastructure.Authorization.Attributes;

public class HasPermissionAttribute: AuthorizeAttribute
{
    public HasPermissionAttribute(string permission)
        : base(AuthPolicies.PermissionPrefix + string.Join('_', permission))
    {
    }
}