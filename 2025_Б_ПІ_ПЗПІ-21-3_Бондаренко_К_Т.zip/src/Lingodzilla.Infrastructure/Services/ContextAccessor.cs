﻿using System.Security.Claims;
using Lingodzilla.Abstractions.Infrastructure.Services;
using Microsoft.AspNetCore.Http;

namespace Lingodzilla.Infrastructure.Services;

public class ContextAccessor : IContextAccessor
{
    private readonly IHttpContextAccessor _httpContextAccessor;

    public ContextAccessor(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    public Guid CurrentUserId
    {
        get
        {
            var userStringId = _httpContextAccessor.HttpContext?.User.Claims
                .FirstOrDefault(x => x.Type == ClaimTypes.NameIdentifier)?.Value;
            if (userStringId is null || !Guid.TryParse(userStringId, out var userId))
            {
                throw new ApplicationException("User not specified");
            }

            return userId;
        }
    }
}