﻿using Lingodzilla.Abstractions.Infrastructure.Services;
using Lingodzilla.Infrastructure.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Lingodzilla.Infrastructure;

public static class DependencyRegistrar
{
    public static void ConfigureInfrastructureDependencies(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.AddScoped<IContextAccessor, ContextAccessor>();
    }
    
    
}