﻿namespace Lingodzilla.Abstractions.Persistence;

public interface IUnitOfWork
{
    int SaveChanges();
    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
    T GetRepository<T>();
}