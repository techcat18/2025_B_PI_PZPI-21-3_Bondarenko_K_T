﻿using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Abstractions.Persistence.Repositories;

public interface IUserLessonProgressRepository : IGenericRepository<UserLessonProgress>
{
    Task<UserLessonProgress?> FindAsync(Guid userId, Guid lessonId, CancellationToken cancellationToken = default);
}