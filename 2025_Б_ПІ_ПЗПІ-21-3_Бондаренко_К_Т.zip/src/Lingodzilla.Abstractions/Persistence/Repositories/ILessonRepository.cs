﻿using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Abstractions.Persistence.Repositories;

public interface ILessonRepository : IGenericRepository<Lesson>
{
    Task<IEnumerable<Lesson>> GetByCourseAsync(Guid courseId, CancellationToken cancellationToken = default);
}