﻿using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Abstractions.Persistence.Repositories;

public interface ITopicRepository : IGenericRepository<Topic>
{
}