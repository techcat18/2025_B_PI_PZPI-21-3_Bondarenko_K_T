﻿using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Abstractions.Persistence.Repositories;

public interface IFriendRequestRepository : IGenericRepository<FriendRequest>
{
    Task<IEnumerable<FriendRequest>> GetPendingByAddresseeIdAsync(
        Guid addresseeId,
        CancellationToken cancellationToken = default);
    
    Task<FriendRequest?> GetByRequesterAndAddresseeIdsAsync(
        Guid requesterId,
        Guid addresseeId,
        CancellationToken cancellationToken = default);
}