﻿using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Abstractions.Persistence.Repositories;

public interface IFlashcardRepository : IGenericRepository<Flashcard>
{
    Task<IEnumerable<Flashcard>> GetByUserAsync(
        Guid userId,
        string? searchQuery,
        bool? isActive,
        CancellationToken cancellationToken = default);
    
    Task<IEnumerable<Flashcard>> GetByUserAndExerciseAsync(
        Guid userId,
        Guid exerciseId,
        CancellationToken cancellationToken = default);
}