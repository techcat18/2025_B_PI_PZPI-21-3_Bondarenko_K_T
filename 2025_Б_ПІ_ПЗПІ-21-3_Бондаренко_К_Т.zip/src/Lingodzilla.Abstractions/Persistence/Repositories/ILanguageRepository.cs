﻿using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Abstractions.Persistence.Repositories;

public interface ILanguageRepository : IGenericRepository<Language>
{
}