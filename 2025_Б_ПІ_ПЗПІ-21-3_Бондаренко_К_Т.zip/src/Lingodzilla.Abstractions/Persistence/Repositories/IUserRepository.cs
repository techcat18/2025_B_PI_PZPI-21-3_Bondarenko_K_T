﻿using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Abstractions.Persistence.Repositories;

public interface IUserRepository
{
    Task<IEnumerable<User>> GetAsync(
        CancellationToken cancellationToken = default);

    Task<IEnumerable<User>> GetFriendsAsync(
        Guid userId,
        CancellationToken cancellationToken = default);
    
    Task<User?> GetByIdAsync(
        Guid id,
        CancellationToken cancellationToken = default);

    Task<User?> GetByPhoneNumberAsync(
        string phoneNumber,
        CancellationToken cancellationToken = default);

    Task<User?> GetByTelegramChatIdAsync(
        long telegramChatId,
        CancellationToken cancellationToken = default);

    Task<List<LeaderboardEntry>> GetCompletedExercisesLeaderboardAsync(
        int limit,
        CancellationToken cancellationToken = default);

    Task<List<LeaderboardEntry>> GetCorrectAnswersLeaderboardAsync(
        int limit,
        CancellationToken cancellationToken = default);

    Task<List<LeaderboardEntry>> GetAccuracyLeaderboardAsync(
        int limit,
        CancellationToken cancellationToken = default);

    Task<List<LeaderboardEntry>> GetCompletedLessonsLeaderboardAsync(
        int limit,
        CancellationToken cancellationToken = default);

    void Update(User user);
    
    Task SaveChangesAsync(CancellationToken cancellationToken = default);
}