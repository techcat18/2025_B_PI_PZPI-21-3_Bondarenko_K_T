﻿using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Abstractions.Persistence.Repositories;

public interface IGenericRepository<T> where T : BaseEntity
{
    IQueryable<T> AsQueryable();
    Task<List<T>> GetAllAsync(CancellationToken cancellationToken = default);
    Task<IQueryable<T>> GetAllAsQueryableAsync(CancellationToken cancellationToken = default);
    Task<T?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default);
    Task AddAsync(T entity, CancellationToken cancellationToken = default);
    void Update(T entity);
    void Delete(T entity);
    Task SaveChangesAsync(CancellationToken cancellationToken = default);
}