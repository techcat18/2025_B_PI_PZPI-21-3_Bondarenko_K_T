﻿using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Abstractions.Persistence.Repositories;

public interface IUserExerciseAttemptRepository : IGenericRepository<UserExerciseAttempt>
{
    Task<IEnumerable<UserExerciseAttempt>> GetAsync(Guid userId, Guid exerciseId, CancellationToken cancellationToken = default);
}