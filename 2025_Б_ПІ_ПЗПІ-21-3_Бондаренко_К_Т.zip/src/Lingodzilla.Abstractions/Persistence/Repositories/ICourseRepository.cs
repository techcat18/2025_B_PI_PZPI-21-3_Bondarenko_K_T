﻿using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Abstractions.Persistence.Repositories;

public interface ICourseRepository : IGenericRepository<Course>
{
    Task<IEnumerable<Course>> GetCoursesByUserAsync(
        Guid id,
        CancellationToken cancellationToken = default);
}