﻿using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Abstractions.Persistence.Repositories;

public interface IUserExerciseProgressRepository : IGenericRepository<UserExerciseProgress>
{
    Task<IEnumerable<UserExerciseProgress>> GetCompletedAsync(Guid userId, List<Guid> exerciseIds, CancellationToken cancellationToken = default);
    Task<UserExerciseProgress?> FindAsync(Guid userId, Guid exerciseId, CancellationToken cancellationToken = default);
}