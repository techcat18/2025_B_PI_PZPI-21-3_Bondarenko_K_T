﻿using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Abstractions.Persistence.Repositories;

public interface IExerciseTypeRepository : IGenericRepository<ExerciseType>
{
}