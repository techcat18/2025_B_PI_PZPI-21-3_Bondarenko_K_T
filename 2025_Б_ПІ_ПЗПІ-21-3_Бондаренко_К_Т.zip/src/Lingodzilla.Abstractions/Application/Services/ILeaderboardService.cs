﻿using Lingodzilla.Common.DTOs.Leaderboard;

namespace Lingodzilla.Abstractions.Application.Services;

public interface ILeaderboardService
{
    Task<IEnumerable<LeaderboardEntryDto>> GetCompletedExercisesLeaderboardAsync(
        int limit,
        CancellationToken ct = default);

    Task<IEnumerable<LeaderboardEntryDto>> GetCorrectAnswersLeaderboardAsync(
        int limit,
        CancellationToken ct = default);

    Task<IEnumerable<LeaderboardEntryDto>> GetAccuracyLeaderboardAsync(
        int limit,
        CancellationToken ct = default);

    Task<IEnumerable<LeaderboardEntryDto>> GetCompletedLessonsLeaderboardAsync(
        int limit,
        CancellationToken ct = default);
}