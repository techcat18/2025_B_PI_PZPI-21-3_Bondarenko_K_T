﻿using Lingodzilla.Common.DTOs.Auth;

namespace Lingodzilla.Abstractions.Application.Services;

public interface IAuthService
{
    Task<JwtModel> LoginAsync(
        LoginDto dto,
        CancellationToken cancellationToken = default);

    Task SignupAsync(
        SignupDto dto,
        CancellationToken cancellationToken = default);

    Task ResetPasswordAsync(
        ChangePasswordModel model,
        CancellationToken cancellationToken = default);
}