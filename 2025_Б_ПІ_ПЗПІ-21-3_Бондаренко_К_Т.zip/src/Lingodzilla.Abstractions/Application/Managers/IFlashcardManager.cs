﻿using Lingodzilla.Common.DTOs.Flashcard;

namespace Lingodzilla.Abstractions.Application.Managers;

public interface IFlashcardManager
{
    Task<IEnumerable<FlashcardDto>> GetFlashcardsAsync(
        GetFlashcardsDto getFlashcardsDto,
        CancellationToken cancellationToken = default);

    Task<FlashcardDto> CreateFlashcardAsync(
        CreateFlashcardDto createFlashcardDto,
        CancellationToken cancellationToken = default);

    Task<FlashcardDto> UpdateFlashcardAsync(
        Guid id,
        UpdateFlashcardDto updateFlashcardDto,
        CancellationToken cancellationToken = default);

    Task DeleteFlashcardAsync(
        Guid id,
        CancellationToken cancellationToken = default);

    Task ImportFlashcardsFromCsvAsync(
        Stream csvStream,
        CancellationToken cancellationToken = default);
}