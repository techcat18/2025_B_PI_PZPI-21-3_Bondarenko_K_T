﻿using Lingodzilla.Common.DTOs.Course;

namespace Lingodzilla.Abstractions.Application.Managers;

public interface ICourseManager
{
    Task<IEnumerable<CourseDto>> GetCoursesAsync(CancellationToken cancellationToken = default);
    Task<CourseDto> GetCourseAsync(Guid id, CancellationToken cancellationToken = default);
    Task<CourseDto> CreateCourseAsync(CreateCourseDto createCourseDto, CancellationToken cancellationToken = default);
    Task<CourseDto> UpdateCourseAsync(Guid id, UpdateCourseDto updateCourseDto, CancellationToken cancellationToken = default);
    Task DeleteCourseAsync(Guid id, CancellationToken cancellationToken = default);
}