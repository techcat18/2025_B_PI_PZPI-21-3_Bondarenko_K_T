﻿using Lingodzilla.Common.DTOs.FriendRequest;

namespace Lingodzilla.Abstractions.Application.Managers;

public interface IFriendRequestManager
{
    Task<IEnumerable<FriendRequestDto>> GetFriendRequestsAsync(
        CancellationToken cancellationToken = default);
    
    Task SendFriendRequestAsync(
        SendFriendRequestDto sendFriendRequestDto, 
        CancellationToken cancellationToken = default);
    
    Task RespondToFriendRequestAsync(
        Guid requestId, 
        RespondToFriendRequestDto respondToFriendRequestDto, 
        CancellationToken cancellationToken = default);
}