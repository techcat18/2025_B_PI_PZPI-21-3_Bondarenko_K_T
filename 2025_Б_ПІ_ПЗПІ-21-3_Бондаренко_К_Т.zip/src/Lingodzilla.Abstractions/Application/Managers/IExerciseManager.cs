﻿using Lingodzilla.Common.DTOs.Exercise;

namespace Lingodzilla.Abstractions.Application.Managers;

public interface IExerciseManager
{
    Task<IEnumerable<ExerciseDto>> GetExercisesByLessonIdAsync(Guid lessonId, CancellationToken cancellationToken = default);
    Task<IEnumerable<ExerciseTypeDto>> GetExerciseTypesAsync(CancellationToken cancellationToken = default);
    Task<ExerciseDto> GetExerciseAsync(Guid id, CancellationToken cancellationToken = default);
    Task<ExerciseDto> CreateExerciseAsync(CreateExerciseDto createExerciseDto, CancellationToken cancellationToken = default);
    Task<ExerciseDto> UpdateExerciseAsync(Guid id, UpdateExerciseDto updateExerciseDto, CancellationToken cancellationToken = default);
    Task DeleteExerciseAsync(Guid id, CancellationToken cancellationToken = default);
    Task<bool> DoExerciseAsync(
        Guid exerciseId,
        DoExerciseDto doExerciseDto, 
        CancellationToken cancellationToken = default);
}