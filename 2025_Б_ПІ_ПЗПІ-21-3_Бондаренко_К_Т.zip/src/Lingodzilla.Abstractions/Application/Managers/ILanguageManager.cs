﻿using Lingodzilla.Common.DTOs.Language;

namespace Lingodzilla.Abstractions.Application.Managers;

public interface ILanguageManager
{
    Task<IEnumerable<LanguageDto>> GetLanguagesAsync(CancellationToken cancellationToken = default);
}