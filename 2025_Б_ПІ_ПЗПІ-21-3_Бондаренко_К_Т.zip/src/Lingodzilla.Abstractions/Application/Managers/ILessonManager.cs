﻿using Lingodzilla.Common.DTOs.Lesson;

namespace Lingodzilla.Abstractions.Application.Managers;

public interface ILessonManager
{
    Task<IEnumerable<LessonDto>> GetByCourseAsync(Guid courseId, CancellationToken cancellationToken = default);
    Task<LessonDto> GetLessonAsync(Guid id, CancellationToken cancellationToken = default);
    Task<LessonDto> CreateLessonAsync(CreateLessonDto createLessonDto, CancellationToken cancellationToken = default);
    Task<LessonDto> UpdateLessonAsync(Guid id, UpdateLessonDto updateLessonDto, CancellationToken cancellationToken = default);
    Task DeleteLessonAsync(Guid id, CancellationToken cancellationToken = default);
}