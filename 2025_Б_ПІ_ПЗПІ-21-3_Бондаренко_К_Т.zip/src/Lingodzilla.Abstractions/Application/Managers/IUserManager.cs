﻿using Lingodzilla.Common.DTOs.User;

namespace Lingodzilla.Abstractions.Application.Managers;

public interface IUserManager
{
    Task<IEnumerable<UserDto>> GetUsersAsync(
        CancellationToken cancellationToken = default);

    Task<IEnumerable<UserDto>> GetFriendsAsync(
        CancellationToken cancellationToken = default);
    
    Task<UserDto?> GetCurrentUserAsync(
        CancellationToken cancellationToken = default);

    Task<UserDto> UpdateUserAsync(
        UpdateUserDto updateUserDto,
        CancellationToken cancellationToken = default);
    
    Task UpdateUserPreferencesAsync(
        UpdateUserPreferencesDto updateUserPreferencesDto,
        CancellationToken cancellationToken = default);
}