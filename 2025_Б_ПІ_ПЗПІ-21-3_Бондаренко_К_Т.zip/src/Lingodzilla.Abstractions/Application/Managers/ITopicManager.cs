﻿using Lingodzilla.Common.DTOs.Topic;

namespace Lingodzilla.Abstractions.Application.Managers;

public interface ITopicManager
{
    Task<IEnumerable<TopicDto>> GetTopicsAsync(CancellationToken cancellationToken = default);
}