﻿using Lingodzilla.Common.DTOs.UserProgress;

namespace Lingodzilla.Abstractions.Application.Managers;

public interface IUserProgressManager
{
    Task<UserProgressDto> GetUserProgressAsync(
        Guid userId,
        Guid lessonId,
        CancellationToken cancellationToken = default);
    
    Task<UserProgressDto> CreateUserProgressAsync(
        Guid userId,
        CreateUserProgressDto createUserProgressDto,
        CancellationToken cancellationToken = default);

    Task<UserProgressDto> UpdateUserProgressAsync(
        Guid userId,
        Guid id,
        UpdateUserProgressDto updateUserProgressDto,
        CancellationToken cancellationToken = default);
}