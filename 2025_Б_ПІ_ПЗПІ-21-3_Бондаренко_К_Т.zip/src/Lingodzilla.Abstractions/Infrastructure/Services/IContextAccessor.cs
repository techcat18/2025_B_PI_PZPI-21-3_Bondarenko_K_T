﻿namespace Lingodzilla.Abstractions.Infrastructure.Services;

public interface IContextAccessor
{
     Guid CurrentUserId { get; }
}