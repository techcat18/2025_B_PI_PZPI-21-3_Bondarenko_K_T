﻿using Lingodzilla.Abstractions.Application.Managers;
using Lingodzilla.Common.Constants;
using Microsoft.AspNetCore.Mvc;

namespace Lingodzilla.Api.Controllers;

[ApiController]
[Route(ApiEndpoints.Users.Base)]
public class UserController : ControllerBase
{
    private readonly IUserManager _userManager;

    public UserController(IUserManager userManager)
    {
        _userManager = userManager;
    }

    [HttpGet(ApiEndpoints.Users.Get)]
    public async Task<IActionResult> GetUsers(
        CancellationToken cancellationToken = default)
    {
        var users = await _userManager.GetUsersAsync(cancellationToken);
        return Ok(users);
    }
}