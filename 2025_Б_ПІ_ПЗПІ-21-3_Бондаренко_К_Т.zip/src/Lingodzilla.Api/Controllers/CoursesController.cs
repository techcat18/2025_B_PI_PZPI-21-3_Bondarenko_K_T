﻿using Lingodzilla.Abstractions.Application.Managers;
using Lingodzilla.Common.Constants;
using Lingodzilla.Common.DTOs.Course;
using Microsoft.AspNetCore.Mvc;

namespace Lingodzilla.Api.Controllers;

[ApiController]
[Route(ApiEndpoints.Courses.Base)]
public class CoursesController : ControllerBase
{
    private readonly ICourseManager _courseManager;

    public CoursesController(ICourseManager courseManager)
    {
        _courseManager = courseManager;
    }

    [HttpGet(ApiEndpoints.Courses.Get)]
    public async Task<IActionResult> Get(
        CancellationToken cancellationToken)
    {
        var courses = await _courseManager.GetCoursesAsync(cancellationToken);
        return Ok(courses);
    }

    [HttpGet(ApiEndpoints.Courses.GetById)]
    public async Task<IActionResult> GetById(
        [FromRoute] Guid id,
        CancellationToken cancellationToken)
    {
        var course = await _courseManager.GetCourseAsync(id, cancellationToken);
        return Ok(course);
    }

    [HttpPost(ApiEndpoints.Courses.Create)]
    public async Task<IActionResult> Create(
        [FromBody] CreateCourseDto createCourseDto,
        CancellationToken cancellationToken)
    {
        var course = await _courseManager.CreateCourseAsync(createCourseDto, cancellationToken);
        return Ok(course);
    }

    [HttpPut(ApiEndpoints.Courses.Update)]
    public async Task<IActionResult> Update(
        [FromRoute] Guid id,
        [FromBody] UpdateCourseDto updateCourseDto,
        CancellationToken cancellationToken)
    {
        var course = await _courseManager.UpdateCourseAsync(id, updateCourseDto, cancellationToken);
        return Ok(course);
    }

    [HttpDelete(ApiEndpoints.Courses.Delete)]
    public async Task<IActionResult> Delete(
        [FromRoute] Guid id,
        CancellationToken cancellationToken)
    {
        await _courseManager.DeleteCourseAsync(id, cancellationToken);
        return NoContent();
    }
}