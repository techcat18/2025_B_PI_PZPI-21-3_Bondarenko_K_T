﻿using Lingodzilla.Abstractions.Application.Managers;
using Lingodzilla.Common.Constants;
using Lingodzilla.Common.DTOs.Lesson;
using Microsoft.AspNetCore.Mvc;

namespace Lingodzilla.Api.Controllers;

[ApiController]
[Route(ApiEndpoints.Lessons.Base)]
public class LessonsController : ControllerBase
{
    private readonly ILessonManager _lessonManager;

    public LessonsController(ILessonManager lessonManager)
    {
        _lessonManager = lessonManager;
    }

    [HttpGet(ApiEndpoints.Lessons.GetByCourse)]
    public async Task<IActionResult> GetByCourse(
        [FromRoute] Guid courseId,
        CancellationToken cancellationToken)
    {
        var lessons = await _lessonManager.GetByCourseAsync(courseId, cancellationToken);
        return Ok(lessons);
    }

    [HttpGet(ApiEndpoints.Lessons.GetById)]
    public async Task<IActionResult> GetById(
        [FromRoute] Guid id,
        CancellationToken cancellationToken)
    {
        var lesson = await _lessonManager.GetLessonAsync(id, cancellationToken);
        return Ok(lesson);
    }

    [HttpPost(ApiEndpoints.Lessons.Create)]
    public async Task<IActionResult> Create(
        [FromBody] CreateLessonDto createLessonDto,
        CancellationToken cancellationToken)
    {
        var lesson = await _lessonManager.CreateLessonAsync(createLessonDto, cancellationToken);
        return Ok(lesson);
    }

    [HttpPut(ApiEndpoints.Lessons.Update)]
    public async Task<IActionResult> Update(
        [FromRoute] Guid id,
        [FromBody] UpdateLessonDto updateLessonDto,
        CancellationToken cancellationToken)
    {
        var lesson = await _lessonManager.UpdateLessonAsync(id, updateLessonDto, cancellationToken);
        return Ok(lesson);
    }

    [HttpDelete(ApiEndpoints.Lessons.Delete)]
    public async Task<IActionResult> Delete(
        [FromRoute] Guid id,
        CancellationToken cancellationToken)
    {
        await _lessonManager.DeleteLessonAsync(id, cancellationToken);
        return NoContent();
    }
}