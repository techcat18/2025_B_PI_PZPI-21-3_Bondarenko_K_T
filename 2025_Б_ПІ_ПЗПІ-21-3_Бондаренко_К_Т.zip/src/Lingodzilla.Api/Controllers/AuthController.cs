﻿using Lingodzilla.Abstractions.Application.Services;
using Lingodzilla.Common.Constants;
using Lingodzilla.Common.DTOs.Auth;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Lingodzilla.Api.Controllers;

[ApiController]
[Route(ApiEndpoints.Auth.Base)]
public class AuthController: ControllerBase
{
    private readonly IAuthService _authService;

    public AuthController(
        IAuthService authService)
    {
        _authService = authService;
    }

    [AllowAnonymous]
    [HttpPost(ApiEndpoints.Auth.Login)]
    [ProducesResponseType(StatusCodes.Status200OK, Type = typeof(JwtModel))]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Login(LoginDto loginDto)
    {
        var token = await _authService.LoginAsync(loginDto);
        return Ok(token);
    }

    [AllowAnonymous]
    [HttpPost(ApiEndpoints.Auth.Signup)]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public async Task<IActionResult> Signup(SignupDto signupDto)
    {
        await _authService.SignupAsync(signupDto);
        return Ok();
    }

    [HttpPut(ApiEndpoints.Auth.ChangePassword)]
    public async Task<IActionResult> ChangePassword(
        ChangePasswordModel changePasswordModel)
    {
        await _authService.ResetPasswordAsync(changePasswordModel);
        return NoContent();
    }
}