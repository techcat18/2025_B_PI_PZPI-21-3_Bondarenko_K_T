﻿using Lingodzilla.Abstractions.Application.Managers;
using Lingodzilla.Common.Constants;
using Microsoft.AspNetCore.Mvc;

namespace Lingodzilla.Api.Controllers;

[ApiController]
[Route(ApiEndpoints.Languages.Base)]
public class LanguagesController : ControllerBase
{
    private readonly ILanguageManager _languageManager;

    public LanguagesController(ILanguageManager languageManager)
    {
        _languageManager = languageManager;
    }

    [HttpGet(ApiEndpoints.Languages.Get)]
    public async Task<IActionResult> GetLanguages(
        CancellationToken cancellationToken)
    {
        var languages = await _languageManager.GetLanguagesAsync(cancellationToken);
        return Ok(languages);
    }
}