﻿using Lingodzilla.Abstractions.Application.Services;
using Lingodzilla.Common.Constants;
using Microsoft.AspNetCore.Mvc;

namespace Lingodzilla.Api.Controllers;

[ApiController]
[Route(ApiEndpoints.Leaderboards.Base)]
public class LeaderboardsController : ControllerBase
{
    private readonly ILeaderboardService _leaderboardService;

    public LeaderboardsController(ILeaderboardService leaderboardService)
    {
        _leaderboardService = leaderboardService;
    }

    [HttpGet(ApiEndpoints.Leaderboards.ByCompletedExercises)]
    public async Task<IActionResult> GetByCompletedExercises(
        [FromQuery] int limit = 10,
        CancellationToken cancellationToken = default)
    {
        var leaderboardEntries = await _leaderboardService.GetCompletedExercisesLeaderboardAsync(
            limit,
            cancellationToken);
        return Ok(leaderboardEntries);
    }
    
    [HttpGet(ApiEndpoints.Leaderboards.ByCorrectAnswers)]
    public async Task<IActionResult> GetByCorrectAnswers(
        [FromQuery] int limit = 10,
        CancellationToken cancellationToken = default)
    {
        var leaderboardEntries = await _leaderboardService.GetCorrectAnswersLeaderboardAsync(
            limit,
            cancellationToken);
        return Ok(leaderboardEntries);
    }
    
    [HttpGet(ApiEndpoints.Leaderboards.ByAccuracy)]
    public async Task<IActionResult> GetByAccuracy(
        [FromQuery] int limit = 10,
        CancellationToken cancellationToken = default)
    {
        var leaderboardEntries = await _leaderboardService.GetAccuracyLeaderboardAsync(
            limit,
            cancellationToken);
        return Ok(leaderboardEntries);
    }
    
    [HttpGet(ApiEndpoints.Leaderboards.ByCompletedLessons)]
    public async Task<IActionResult> GetByCompletedLessons(
        [FromQuery] int limit = 10,
        CancellationToken cancellationToken = default)
    {
        var leaderboardEntries = await _leaderboardService.GetCompletedLessonsLeaderboardAsync(
            limit,
            cancellationToken);
        return Ok(leaderboardEntries);
    }
}