﻿using Lingodzilla.Abstractions.Application.Managers;
using Lingodzilla.Abstractions.Infrastructure.Services;
using Lingodzilla.Common.Constants;
using Lingodzilla.Common.DTOs.UserProgress;
using Microsoft.AspNetCore.Mvc;

namespace Lingodzilla.Api.Controllers;

[ApiController]
[Route(ApiEndpoints.UserProgresses.Base)]
public class UserProgressesController : ControllerBase
{
    private readonly IUserProgressManager _userProgressManager;
    private readonly IContextAccessor _contextAccessor;

    public UserProgressesController(
        IUserProgressManager userProgressManager, 
        IContextAccessor contextAccessor)
    {
        _userProgressManager = userProgressManager;
        _contextAccessor = contextAccessor;
    }

    [HttpGet(ApiEndpoints.UserProgresses.Get)]
    public async Task<IActionResult> Get(
        [FromRoute] Guid lessonId,
        CancellationToken cancellationToken)
    {
        var userProgresses = await _userProgressManager.GetUserProgressAsync(
            _contextAccessor.CurrentUserId,
            lessonId,
            cancellationToken);
        return Ok(userProgresses);
    }

    [HttpPost(ApiEndpoints.UserProgresses.Create)]
    public async Task<IActionResult> Create(
        [FromBody] CreateUserProgressDto createUserProgressDto,
        CancellationToken cancellationToken)
    {
        var userProgress = await _userProgressManager.CreateUserProgressAsync(
            _contextAccessor.CurrentUserId,
            createUserProgressDto,
            cancellationToken);
        return Ok(userProgress);
    }

    [HttpPut(ApiEndpoints.UserProgresses.Update)]
    public async Task<IActionResult> Update(
        [FromRoute] Guid id,
        [FromBody] UpdateUserProgressDto updateUserProgressDto,
        CancellationToken cancellationToken)
    {
        var userProgress = await _userProgressManager.UpdateUserProgressAsync(
            _contextAccessor.CurrentUserId,
            id,
            updateUserProgressDto,
            cancellationToken);
        return Ok(userProgress);
    }
}