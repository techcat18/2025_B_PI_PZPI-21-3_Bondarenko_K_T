﻿using Lingodzilla.Abstractions.Application.Managers;
using Lingodzilla.Common.Constants;
using Lingodzilla.Common.DTOs.User;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Lingodzilla.Api.Controllers;

[Authorize]
[ApiController]
[Route(ApiEndpoints.Auth.Base)]
public class CurrentUserController : ControllerBase
{
    private readonly IUserManager _userManager;

    public CurrentUserController(IUserManager userManager)
    {
        _userManager = userManager;
    }

    [HttpGet(ApiEndpoints.Auth.GetUser)]
    public async Task<IActionResult> GetCurrentUser(
        CancellationToken cancellationToken)
    {
        var user = await _userManager.GetCurrentUserAsync(cancellationToken);
        return Ok(user);
    }

    [HttpGet(ApiEndpoints.Auth.GetFriends)]
    public async Task<IActionResult> GetFriends(
        CancellationToken cancellationToken)
    {
        var friends = await _userManager.GetFriendsAsync(cancellationToken);
        return Ok(friends);
    }
    
    [HttpPut(ApiEndpoints.Auth.UpdatePreferences)]
    public async Task<IActionResult> UpdatePreferences(
        [FromBody] UpdateUserPreferencesDto updateUserPreferencesDto,
        CancellationToken cancellationToken)
    {
        await _userManager.UpdateUserPreferencesAsync(updateUserPreferencesDto, cancellationToken);
        return NoContent();
    }

    [HttpPut(ApiEndpoints.Auth.UpdateUser)]
    public async Task<IActionResult> Update(
        [FromBody] UpdateUserDto updateUserDto,
        CancellationToken cancellationToken)
    {
        var user = await _userManager.UpdateUserAsync(updateUserDto, cancellationToken);
        return Ok(user);
    }
}