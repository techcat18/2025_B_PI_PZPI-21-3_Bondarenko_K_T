﻿using Lingodzilla.Abstractions.Application.Managers;
using Lingodzilla.Common.Constants;
using Lingodzilla.Common.DTOs.Flashcard;
using Microsoft.AspNetCore.Mvc;

namespace Lingodzilla.Api.Controllers;

[ApiController]
[Route(ApiEndpoints.Flashcards.Base)]
public class FlashcardsController : ControllerBase
{
    private readonly IFlashcardManager _flashcardManager;

    public FlashcardsController(IFlashcardManager flashcardManager)
    {
        _flashcardManager = flashcardManager;
    }

    [HttpGet(ApiEndpoints.Flashcards.Get)]
    public async Task<IActionResult> Get(
        [FromQuery] GetFlashcardsDto getFlashcardsDto,
        CancellationToken cancellationToken)
    {
        var flashcards = await _flashcardManager.GetFlashcardsAsync(getFlashcardsDto, cancellationToken);
        return Ok(flashcards);
    }
    
    [HttpPost(ApiEndpoints.Flashcards.Create)]
    public async Task<IActionResult> Create(
        [FromBody] CreateFlashcardDto createFlashcardDto,
        CancellationToken cancellationToken)
    {
        var flashcard = await _flashcardManager.CreateFlashcardAsync(createFlashcardDto, cancellationToken);
        return Ok(flashcard);
    }

    [HttpPost(ApiEndpoints.Flashcards.Import)]
    public async Task<IActionResult> Import(
        [FromForm] IFormFile file,
        CancellationToken cancellationToken)
    {
        await _flashcardManager.ImportFlashcardsFromCsvAsync(file.OpenReadStream(), cancellationToken);
        return NoContent();
    }
    
    [HttpPut(ApiEndpoints.Flashcards.Update)]
    public async Task<IActionResult> Update(
        [FromRoute] Guid id,
        [FromBody] UpdateFlashcardDto updateFlashcardDto,
        CancellationToken cancellationToken)
    {
        var flashcard = await _flashcardManager.UpdateFlashcardAsync(id, updateFlashcardDto, cancellationToken);
        return Ok(flashcard);
    }

    [HttpDelete(ApiEndpoints.Flashcards.Delete)]
    public async Task<IActionResult> Delete(
        [FromRoute] Guid id,
        CancellationToken cancellationToken)
    {
        await _flashcardManager.DeleteFlashcardAsync(id, cancellationToken);
        return NoContent();
    }
}