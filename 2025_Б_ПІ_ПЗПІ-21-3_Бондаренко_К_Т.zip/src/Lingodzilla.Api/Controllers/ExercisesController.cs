﻿using Lingodzilla.Abstractions.Application.Managers;
using Lingodzilla.Common.Constants;
using Lingodzilla.Common.DTOs.Exercise;
using Microsoft.AspNetCore.Mvc;

namespace Lingodzilla.Api.Controllers;

[ApiController]
[Route(ApiEndpoints.Exercises.Base)]
public class ExercisesController : ControllerBase
{
    private readonly IExerciseManager _exerciseManager;

    public ExercisesController(IExerciseManager exerciseManager)
    {
        _exerciseManager = exerciseManager;
    }
    
    [HttpGet(ApiEndpoints.Exercises.GetByLesson)]
    public async Task<IActionResult> GetByLesson(
        [FromRoute] Guid id,
        CancellationToken cancellationToken)
    {
        var exercises = await _exerciseManager.GetExercisesByLessonIdAsync(id, cancellationToken);
        return Ok(exercises);
    }

    [HttpGet(ApiEndpoints.Exercises.GetExerciseTypes)]
    public async Task<IActionResult> GetExerciseTypes(
        CancellationToken cancellationToken)
    {
        var exerciseTypes = await _exerciseManager.GetExerciseTypesAsync(cancellationToken);
        return Ok(exerciseTypes);
    }
    
    [HttpGet(ApiEndpoints.Exercises.GetById)]
    public async Task<IActionResult> GetById(
        [FromRoute] Guid id,
        CancellationToken cancellationToken)
    {
        var exercise = await _exerciseManager.GetExerciseAsync(id, cancellationToken);
        return Ok(exercise);
    }

    [HttpPost(ApiEndpoints.Exercises.Create)]
    public async Task<IActionResult> Create(
        [FromBody] CreateExerciseDto createExerciseDto,
        CancellationToken cancellationToken)
    {
        var exercise = await _exerciseManager.CreateExerciseAsync(createExerciseDto, cancellationToken);
        return Ok(exercise);
    }

    [HttpPut(ApiEndpoints.Exercises.Update)]
    public async Task<IActionResult> Update(
        [FromRoute] Guid id,
        [FromBody] UpdateExerciseDto updateExerciseDto,
        CancellationToken cancellationToken)
    {
        var exercise = await _exerciseManager.UpdateExerciseAsync(id, updateExerciseDto, cancellationToken);
        return Ok(exercise);
    }

    [HttpDelete(ApiEndpoints.Exercises.Delete)]
    public async Task<IActionResult> Delete(
        [FromRoute] Guid id,
        CancellationToken cancellationToken)
    {
        await _exerciseManager.DeleteExerciseAsync(id, cancellationToken);
        return NoContent();
    }

    [HttpPost(ApiEndpoints.Exercises.Do)]
    public async Task<IActionResult> DoExercise(
        [FromRoute] Guid id,
        [FromBody] DoExerciseDto doExerciseDto,
        CancellationToken cancellationToken)
    {
        var result = await _exerciseManager.DoExerciseAsync(id, doExerciseDto, cancellationToken);
        return Ok(result);
    }
}