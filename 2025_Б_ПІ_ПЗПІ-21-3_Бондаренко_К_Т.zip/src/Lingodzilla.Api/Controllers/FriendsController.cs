﻿using Lingodzilla.Abstractions.Application.Managers;
using Lingodzilla.Common.Constants;
using Lingodzilla.Common.DTOs.FriendRequest;
using Microsoft.AspNetCore.Mvc;

namespace Lingodzilla.Api.Controllers;

[ApiController]
[Route(ApiEndpoints.Friends.Base)]
public class FriendsController : ControllerBase
{
    private readonly IFriendRequestManager _friendRequestManager;
    private readonly IUserManager _userManager;

    public FriendsController(
        IFriendRequestManager friendRequestManager, 
        IUserManager userManager)
    {
        _friendRequestManager = friendRequestManager;
        _userManager = userManager;
    }

    [HttpGet(ApiEndpoints.Friends.Get)]
    public async Task<IActionResult> GetFriends(
        CancellationToken cancellationToken = default)
    {
        var friends = await _userManager.GetFriendsAsync(cancellationToken);
        return Ok(friends);
    }
    
    [HttpGet(ApiEndpoints.Friends.GetRequests)]
    public async Task<IActionResult> GetFriendRequests(
        CancellationToken cancellationToken = default)
    {
        var friendRequests = await _friendRequestManager.GetFriendRequestsAsync(cancellationToken);
        return Ok(friendRequests);
    }
    
    [HttpPost(ApiEndpoints.Friends.SendRequest)]
    public async Task<IActionResult> SendFriendRequest(
        [FromBody] SendFriendRequestDto sendFriendRequestDto,
        CancellationToken cancellationToken)
    {
        await _friendRequestManager.SendFriendRequestAsync(sendFriendRequestDto, cancellationToken);
        return NoContent();
    }

    [HttpPut(ApiEndpoints.Friends.RespondToRequest)]
    public async Task<IActionResult> RespondToFriendRequest(
        Guid id,
        [FromBody] RespondToFriendRequestDto respondToFriendRequestDto,
        CancellationToken cancellationToken)
    {
        await _friendRequestManager.RespondToFriendRequestAsync(id, respondToFriendRequestDto, cancellationToken);
        return NoContent();
    }
}