﻿using Lingodzilla.Abstractions.Application.Managers;
using Lingodzilla.Common.Constants;
using Microsoft.AspNetCore.Mvc;

namespace Lingodzilla.Api.Controllers;

[ApiController]
[Route(ApiEndpoints.Topics.Base)]
public class TopicsController : ControllerBase
{
    private readonly ITopicManager _topicManager;

    public TopicsController(ITopicManager topicManager)
    {
        _topicManager = topicManager;
    }

    [HttpGet(ApiEndpoints.Topics.Get)]
    public async Task<IActionResult> Get(
        CancellationToken cancellationToken)
    {
        var topics = await _topicManager.GetTopicsAsync(cancellationToken);
        return Ok(topics);
    }
}