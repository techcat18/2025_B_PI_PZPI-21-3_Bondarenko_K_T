﻿namespace Lingodzilla.Common.Constants;

public static class ConfigurationNames
{
    public const string SqlConnectionString = "SqlDatabase";
    public const string BlobStorageConnectionString = "BlobStorage";
}