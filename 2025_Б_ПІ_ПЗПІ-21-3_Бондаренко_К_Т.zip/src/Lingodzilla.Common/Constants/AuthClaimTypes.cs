﻿namespace Lingodzilla.Common.Constants;

public static class AuthClaimTypes
{
    public const string Permissions = "Permissions";
}