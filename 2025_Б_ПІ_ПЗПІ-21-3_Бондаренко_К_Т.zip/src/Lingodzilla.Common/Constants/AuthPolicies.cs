﻿namespace Lingodzilla.Common.Constants;

public static class AuthPolicies
{
    public const string PermissionPrefix = "permission";
}