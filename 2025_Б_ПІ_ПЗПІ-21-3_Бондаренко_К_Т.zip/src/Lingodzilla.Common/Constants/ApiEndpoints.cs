﻿namespace Lingodzilla.Common.Constants;

public static class ApiEndpoints
{
    private const string IdPlaceholder = "{id}";
    
    public static class Auth
    {
        public const string Base = "/api/auth";
        public const string Login = $"{Base}/login";
        public const string Signup = $"{Base}/signup";
        public const string ChangePassword = $"{Base}/changePassword";
        public const string GetUser = $"{Base}/me";
        public const string UpdatePreferences = $"{Base}/preferences";
        public const string GetFriends = $"{Base}/friends";
        public const string UpdateUser = $"{Base}/me";
    }
    
    public static class Languages
    {
        public const string Base = "/api/languages";
        public const string Get = Base;
    }

    public static class Lessons
    {
        public const string Base = "/api/lessons";
        public const string Get = Base;
        public const string GetByCourse = "/api/courses/{courseId}/lessons";
        public const string GetById = $"{Base}/{IdPlaceholder}";
        public const string Create = Base;
        public const string Update = $"{Base}/{IdPlaceholder}";
        public const string Delete = $"{Base}/{IdPlaceholder}";
    }

    public static class Courses
    {
        public const string Base = "/api/courses";
        public const string Get = Base;
        public const string GetById = $"{Base}/{IdPlaceholder}";
        public const string Create = Base;
        public const string Update = $"{Base}/{IdPlaceholder}";
        public const string Delete = $"{Base}/{IdPlaceholder}";
    }
    
    public static class Topics
    {
        public const string Base = "/api/topics";
        public const string Get = Base;
    }

    public static class Exercises
    {
        public const string Base = "/api/exercises";
        public const string GetByLesson = $"/api/lessons/{IdPlaceholder}/exercises";
        public const string GetExerciseTypes = $"{Base}/types";
        public const string GetById = $"{Base}/{IdPlaceholder}";
        public const string Create = Base;
        public const string Update = $"{Base}/{IdPlaceholder}";
        public const string Delete = $"{Base}/{IdPlaceholder}";
        public const string Do = $"{Base}/{IdPlaceholder}/do";
    }

    public static class UserProgresses
    {
        public const string Base = "/api/userProgresses";
        public const string Get = "/api/lessons/{lessonId}/userProgresses";
        public const string Create = Base;
        public const string Update = $"{Base}/{IdPlaceholder}";
    }

    public static class Users
    {
        public const string Base = "/api/users";
        public const string Get = Base;
        public const string GetById = $"{Base}/{IdPlaceholder}";
    }

    public static class Friends
    {
        public const string Base = "/api/friends";
        public const string Get = Base;
        public const string GetRequests = $"{Base}/requests";
        public const string SendRequest = $"{Base}/requests/send";
        public const string RespondToRequest = $"{Base}/requests/respond/{IdPlaceholder}";
    }

    public static class Leaderboards
    {
        public const string Base = "/api/leaderboards";
        public const string ByCompletedExercises = $"{Base}/completedExercises";
        public const string ByCorrectAnswers = $"{Base}/correctAnswers";
        public const string ByAccuracy  = $"{Base}/accuracy";
        public const string ByCompletedLessons = $"{Base}/completedLessons";
    }

    public static class Flashcards
    {
        public const string Base = "/api/flashcards";
        public const string Get = Base;
        public const string Create = Base;
        public const string Import = $"{Base}/import";
        public const string Update = $"{Base}/{IdPlaceholder}";
        public const string Delete = $"{Base}/{IdPlaceholder}";
    }
}