﻿namespace Lingodzilla.Common.DTOs.Topic;

public class TopicDto
{
    public Guid Id { get; init; }
    public string Name { get; init; } = null!;
    public string? Description { get; init; }
}