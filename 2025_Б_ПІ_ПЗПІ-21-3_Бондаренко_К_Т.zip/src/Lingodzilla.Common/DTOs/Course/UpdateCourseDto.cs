﻿namespace Lingodzilla.Common.DTOs.Course;

public class UpdateCourseDto
{
    public string Name { get; init; } = null!;
    public string? Description { get; init; }
    public Guid LanguageId { get; init; }
    public Guid TargetLanguageId { get; init; }
}