﻿using Lingodzilla.Common.DTOs.Language;
using Lingodzilla.Common.DTOs.User;

namespace Lingodzilla.Common.DTOs.Course;

public class CourseDto
{
    public Guid Id { get; init; }
    public string Name { get; init; } = null!;
    public string? Description { get; init; }
    public LanguageDto Language { get; init; } = null!;
    public LanguageDto TargetLanguage { get; init; } = null!;
    public UserDto? User { get; init; }
}