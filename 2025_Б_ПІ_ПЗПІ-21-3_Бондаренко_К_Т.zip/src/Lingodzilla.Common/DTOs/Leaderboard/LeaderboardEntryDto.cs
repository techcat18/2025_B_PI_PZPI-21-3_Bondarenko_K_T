﻿using Lingodzilla.Common.DTOs.User;

namespace Lingodzilla.Common.DTOs.Leaderboard;

public class LeaderboardEntryDto
{
    public UserDto User { get; init; } = null!;
    public double Score { get; init; }
}