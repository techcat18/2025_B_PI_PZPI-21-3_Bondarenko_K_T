﻿namespace Lingodzilla.Common.DTOs.Language;

public class LanguageDto
{
    public Guid Id { get; init; }
    public string Name { get; init; } = null!;
    public string Code { get; init; } = null!;
}