﻿namespace Lingodzilla.Common.DTOs.UserProgress;

public class UserProgressDto
{
    public int Score { get; init; }
    public DateTime CompletedAt { get; init; }
    public Guid UserId { get; init; }
    public Guid LessonId { get; init; }
}