﻿namespace Lingodzilla.Common.DTOs.UserProgress;

public class CreateUserProgressDto
{
    public int Score { get; init; }
    public Guid LessonId { get; init; }
}