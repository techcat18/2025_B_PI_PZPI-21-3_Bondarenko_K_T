﻿namespace Lingodzilla.Common.DTOs.UserProgress;

public class UpdateUserProgressDto
{
    public int Score { get; init; }
    public Guid LessonId { get; init; }
}