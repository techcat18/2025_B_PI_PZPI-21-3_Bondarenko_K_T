﻿namespace Lingodzilla.Common.DTOs.Word;

public class TranslateWordDto
{
    public Guid LanguageId { get; init; }
}