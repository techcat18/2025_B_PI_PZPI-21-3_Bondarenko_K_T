﻿namespace Lingodzilla.Common.DTOs.Word;

public class WordDto
{
    public string Text { get; init; } = null!;
    public string? Translation { get; init; }
    public string? PartOfSpeech { get; init; }
    public string? ExampleSentence { get; init; }
}