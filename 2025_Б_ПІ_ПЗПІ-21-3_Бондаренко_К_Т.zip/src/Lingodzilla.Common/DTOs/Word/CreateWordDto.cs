﻿namespace Lingodzilla.Common.DTOs.Word;

public class CreateWordDto
{
    public string Value { get; init; } = null!;
    public bool IsPublic { get; init; }
    public Guid LanguageId { get; init; }
}