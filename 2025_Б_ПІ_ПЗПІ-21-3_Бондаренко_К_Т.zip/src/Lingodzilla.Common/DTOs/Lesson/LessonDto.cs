﻿namespace Lingodzilla.Common.DTOs.Lesson;

public class LessonDto
{
    public Guid Id { get; init; }
    public string Name { get; init; } = null!;
    public int OrderIndex { get; init; }
    public Guid CourseId { get; init; }
}