﻿namespace Lingodzilla.Common.DTOs.Lesson;

public class UpdateLessonDto
{
    public string Name { get; init; } = null!;
    public int OrderIndex { get; init; }
}