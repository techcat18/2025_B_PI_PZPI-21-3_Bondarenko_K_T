﻿namespace Lingodzilla.Common.DTOs.Lesson;

public class CreateLessonDto
{
    public string Name { get; init; } = null!;
    public int OrderIndex { get; init; }
    public Guid CourseId { get; init; }
}