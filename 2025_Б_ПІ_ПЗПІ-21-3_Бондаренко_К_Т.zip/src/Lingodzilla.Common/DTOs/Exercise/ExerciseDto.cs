﻿using Lingodzilla.Common.DTOs.Word;
using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Common.DTOs.Exercise;

public class ExerciseDto
{
    public Guid Id { get; init; }
    public string Question { get; init; } = null!;
    public string? AudioUrl { get; init; }
    public string CorrectAnswer { get; init; } = null!;
    public ExerciseTypeDto ExerciseType { get; init; } = null!;
    public Guid LessonId { get; init; }
    public List<WordDto> Words { get; init; } = [];
    public List<ExerciseOption> Options { get; init; } = [];
}