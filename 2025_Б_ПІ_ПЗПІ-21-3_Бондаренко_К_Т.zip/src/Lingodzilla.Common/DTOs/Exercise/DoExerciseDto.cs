﻿namespace Lingodzilla.Common.DTOs.Exercise;

public class DoExerciseDto
{
    public string SubmittedAnswer { get; init; } = null!;
}