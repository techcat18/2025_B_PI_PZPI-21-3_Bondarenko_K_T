﻿namespace Lingodzilla.Common.DTOs.Exercise;

public class ExerciseOptionDto
{
    public Guid Id { get; init; }
    public string OptionText { get; init; } = null!;
    public bool IsCorrect { get; init; }
    public Guid ExerciseId { get; init; }
}