﻿using Lingodzilla.Common.DTOs.Word;
using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Common.DTOs.Exercise;

public class CreateExerciseDto
{
    public string Question { get; init; } = null!;
    public string CorrectAnswer { get; init; } = null!;
    public Guid ExerciseTypeId { get; init; }
    public Guid LessonId { get; init; }
    public string? Explanation { get; init; }
    public List<WordDto> Words { get; init; } = [];
    public List<ExerciseOption> Options { get; init; } = [];
}