﻿namespace Lingodzilla.Common.DTOs.Exercise;

public class UpdateExerciseDto
{
    public string Question { get; init; } = null!;
    public string CorrectAnswer { get; init; } = null!;
    public Guid ExerciseTypeId { get; init; }
    public string? Explanation { get; init; }
}