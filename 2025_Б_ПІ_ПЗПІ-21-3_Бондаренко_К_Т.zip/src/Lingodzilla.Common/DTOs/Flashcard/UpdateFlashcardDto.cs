﻿namespace Lingodzilla.Common.DTOs.Flashcard;

public class UpdateFlashcardDto
{
    public bool IsActive { get; init; }
}