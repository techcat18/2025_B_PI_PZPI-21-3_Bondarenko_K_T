﻿namespace Lingodzilla.Common.DTOs.Flashcard;

public class ImportFlashcardCsvDto
{
    public string Text { get; init; } = null!;
    public string Translation { get; init; } = null!;
    public string? PartOfSpeech { get; init; }
    public string? ExampleSentence { get; init; }
}