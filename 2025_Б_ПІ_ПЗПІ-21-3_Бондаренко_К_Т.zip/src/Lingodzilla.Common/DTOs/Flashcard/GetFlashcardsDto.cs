﻿namespace Lingodzilla.Common.DTOs.Flashcard;

public class GetFlashcardsDto
{
    public string? SearchQuery { get; init; }
    public bool? IsActive { get; set; }
}