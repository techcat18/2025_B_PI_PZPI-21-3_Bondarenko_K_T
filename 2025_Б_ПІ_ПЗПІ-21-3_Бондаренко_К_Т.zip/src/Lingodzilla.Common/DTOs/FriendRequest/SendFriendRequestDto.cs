﻿namespace Lingodzilla.Common.DTOs.FriendRequest;

public class SendFriendRequestDto
{
    public Guid ToUserId { get; init; }
}