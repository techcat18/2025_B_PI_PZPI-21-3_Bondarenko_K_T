﻿namespace Lingodzilla.Common.DTOs.FriendRequest;

public class RespondToFriendRequestDto
{
    public bool Accepted { get; init; }
}