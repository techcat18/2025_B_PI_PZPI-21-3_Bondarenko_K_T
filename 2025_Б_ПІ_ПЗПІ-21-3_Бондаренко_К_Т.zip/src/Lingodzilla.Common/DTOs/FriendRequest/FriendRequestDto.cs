﻿using Lingodzilla.Common.DTOs.User;
using Lingodzilla.Domain.Enums;

namespace Lingodzilla.Common.DTOs.FriendRequest;

public class FriendRequestDto
{
    public Guid Id { get; init; }
    public Guid RequesterId { get; init; }
    public UserDto Requester { get; init; } = null!;
    public Guid AddresseeId { get; init; }
    public UserDto Addressee { get; init; } = null!;
    public FriendRequestStatus Status { get; init; }
    public DateTime RequestedAt { get; init; }
    public DateTime? RespondedAt { get; init; }
}