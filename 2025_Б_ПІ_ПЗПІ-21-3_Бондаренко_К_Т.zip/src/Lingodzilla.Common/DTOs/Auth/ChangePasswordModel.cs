﻿namespace Lingodzilla.Common.DTOs.Auth;

public class ChangePasswordModel
{
    public string Email { get; init; } = null!;
    public string Password { get; init; } = null!;
}