﻿namespace Lingodzilla.Common.DTOs.Auth;

public class JwtModel
{
    public string Token { get; init; } = null!;
}