﻿namespace Lingodzilla.Common.DTOs.User;

public class UpdateUserDto
{
    public string? PhoneNumber { get; init; }
    public bool SendReminders { get; init; }
}