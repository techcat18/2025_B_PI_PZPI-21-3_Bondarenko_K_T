﻿namespace Lingodzilla.Common.DTOs.User;

public class UpdateUserPreferencesDto
{
    
}