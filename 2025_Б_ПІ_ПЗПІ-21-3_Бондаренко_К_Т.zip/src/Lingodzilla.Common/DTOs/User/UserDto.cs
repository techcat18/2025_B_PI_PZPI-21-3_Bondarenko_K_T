﻿namespace Lingodzilla.Common.DTOs.User;

public class UserDto
{
    public Guid Id { get; init; }
    public string Email { get; init; } = null!;
    public string UserName { get; init; } = null!;
    public string? PhoneNumber { get; init; }
    public bool SendReminders { get; init; }
}