﻿using System.IdentityModel.Tokens.Jwt;
using AutoMapper;
using Lingodzilla.Abstractions.Application.Services;
using Lingodzilla.Common.DTOs.Auth;
using Lingodzilla.Domain.Entities;
using Microsoft.AspNetCore.Identity;

namespace Lingodzilla.Application.Services;

public class AuthService : IAuthService
{
    private readonly UserManager<User> _userManager;
    private readonly SignInManager<User> _signInManager;
    private readonly IMapper _mapper;
    private readonly IJwtService _jwtHandler;

    public AuthService(
        UserManager<User> userManager,
        SignInManager<User> signInManager,
        IMapper mapper, 
        IJwtService jwtHandler)
    {
        _userManager = userManager;
        _signInManager = signInManager;
        _mapper = mapper;
        _jwtHandler = jwtHandler;
    }

    public async Task<JwtModel> LoginAsync(
        LoginDto dto,
        CancellationToken cancellationToken = default)
    {
        var user = await _userManager.FindByEmailAsync(dto.Email)
            ?? throw new ApplicationException("Invalid email or password");

        var result = await _signInManager
            .PasswordSignInAsync(user, dto.Password, false, false);

        if (!result.Succeeded)
        {
            throw new ApplicationException("Invalid email or password");
        }

        var claims = await _jwtHandler.GetClaimsAsync(user.Id.ToString());
        var signingCredentials = _jwtHandler.GetSigningCredentials();
        var token = _jwtHandler.GenerateToken(signingCredentials, claims);

        return new JwtModel
        {
            Token = new JwtSecurityTokenHandler().WriteToken(token),
        };
    }

    public async Task SignupAsync(
        SignupDto dto,
        CancellationToken cancellationToken = default)
    {
        var user = _mapper.Map<User>(dto);

        var result = await _userManager.CreateAsync(user, dto.Password);

        if (!result.Succeeded)
        {
            throw new ApplicationException(result.ToString());
        }
    }

    public async Task ResetPasswordAsync(
        ChangePasswordModel model,
        CancellationToken cancellationToken = default)
    {
        var user = await _userManager.FindByEmailAsync(model.Email)
                   ?? throw new ApplicationException($"User with email {model.Email} was not found");

        var token = await _userManager.GeneratePasswordResetTokenAsync(user);
        var result = await _userManager.ResetPasswordAsync(user, token, model.Password);

        if (!result.Succeeded)
        {
            throw new ApplicationException("Failed to reset password");
        }
    }
}