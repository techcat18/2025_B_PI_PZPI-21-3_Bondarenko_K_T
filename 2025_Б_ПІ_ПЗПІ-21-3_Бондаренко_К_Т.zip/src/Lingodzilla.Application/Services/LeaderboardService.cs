﻿using AutoMapper;
using Lingodzilla.Abstractions.Application.Services;
using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Common.DTOs.Leaderboard;

namespace Lingodzilla.Application.Services;

public class LeaderboardService : ILeaderboardService
{
    private readonly IUserRepository _userRepository;
    private readonly IMapper _mapper;

    public LeaderboardService(
        IUserRepository userRepository, 
        IMapper mapper)
    {
        _userRepository = userRepository;
        _mapper = mapper;
    }

    public async Task<IEnumerable<LeaderboardEntryDto>> GetCompletedExercisesLeaderboardAsync(
        int limit, 
        CancellationToken ct = default)
    {
        var leaderboardEntries = await _userRepository.GetCompletedExercisesLeaderboardAsync(limit, ct);
        return _mapper.Map<IEnumerable<LeaderboardEntryDto>>(leaderboardEntries);
    }

    public async Task<IEnumerable<LeaderboardEntryDto>> GetCorrectAnswersLeaderboardAsync(
        int limit, 
        CancellationToken ct = default)
    {
        var leaderboardEntries = await _userRepository.GetCorrectAnswersLeaderboardAsync(limit, ct);
        return _mapper.Map<IEnumerable<LeaderboardEntryDto>>(leaderboardEntries);
    }

    public async Task<IEnumerable<LeaderboardEntryDto>> GetAccuracyLeaderboardAsync(
        int limit, 
        CancellationToken ct = default)
    {
        var leaderboardEntries = await _userRepository.GetAccuracyLeaderboardAsync(limit, ct);
        return _mapper.Map<IEnumerable<LeaderboardEntryDto>>(leaderboardEntries);
    }

    public async Task<IEnumerable<LeaderboardEntryDto>> GetCompletedLessonsLeaderboardAsync(
        int limit, 
        CancellationToken ct = default)
    {
        var leaderboardEntries = await _userRepository.GetCompletedLessonsLeaderboardAsync(limit, ct);
        return _mapper.Map<IEnumerable<LeaderboardEntryDto>>(leaderboardEntries);
    }
}