﻿using AutoMapper;
using Lingodzilla.Common.DTOs.UserProgress;
using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Application.MappingProfiles;

public class UserProgressProfile : Profile
{
    public UserProgressProfile()
    {
        CreateMap<UserProgress, UserProgressDto>();
        CreateMap<CreateUserProgressDto, UserProgress>();
    }
}