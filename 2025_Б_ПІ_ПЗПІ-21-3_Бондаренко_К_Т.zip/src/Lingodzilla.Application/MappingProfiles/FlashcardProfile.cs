﻿using AutoMapper;
using Lingodzilla.Common.DTOs.Flashcard;
using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Application.MappingProfiles;

public class FlashcardProfile : Profile
{
    public FlashcardProfile()
    {
        CreateMap<Flashcard, FlashcardDto>();
    }
}