﻿using AutoMapper;
using Lingodzilla.Common.DTOs.Language;
using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Application.MappingProfiles;

public class LanguageProfile : Profile
{
    public LanguageProfile()
    {
        CreateMap<Language, LanguageDto>();
    }
}