﻿using AutoMapper;
using Lingodzilla.Common.DTOs.Course;
using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Application.MappingProfiles;

public class CourseProfile : Profile
{
    public CourseProfile()
    {
        CreateMap<Course, CourseDto>();
        CreateMap<CreateCourseDto, Course>();
    }
}