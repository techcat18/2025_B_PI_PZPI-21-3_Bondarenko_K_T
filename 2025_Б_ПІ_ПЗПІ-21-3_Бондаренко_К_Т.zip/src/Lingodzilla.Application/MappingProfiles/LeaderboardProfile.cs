﻿using AutoMapper;
using Lingodzilla.Common.DTOs.Leaderboard;
using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Application.MappingProfiles;

public class LeaderboardProfile : Profile
{
    public LeaderboardProfile()
    {
        CreateMap<LeaderboardEntry, LeaderboardEntryDto>();
    }
}