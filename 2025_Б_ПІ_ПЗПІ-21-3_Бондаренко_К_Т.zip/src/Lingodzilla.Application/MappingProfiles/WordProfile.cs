﻿using AutoMapper;
using Lingodzilla.Common.DTOs.Word;
using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Application.MappingProfiles;

public class WordProfile : Profile
{
    public WordProfile()
    {
        CreateMap<Word, WordDto>().ReverseMap();
    }
}