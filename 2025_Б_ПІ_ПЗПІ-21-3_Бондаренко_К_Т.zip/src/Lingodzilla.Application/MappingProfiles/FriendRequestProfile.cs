﻿using AutoMapper;
using Lingodzilla.Common.DTOs.FriendRequest;
using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Application.MappingProfiles;

public class FriendRequestProfile : Profile
{
    public FriendRequestProfile()
    {
        CreateMap<FriendRequest, FriendRequestDto>();
    }
}