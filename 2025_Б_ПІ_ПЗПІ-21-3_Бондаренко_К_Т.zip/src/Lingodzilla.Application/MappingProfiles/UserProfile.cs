﻿using AutoMapper;
using Lingodzilla.Common.DTOs.Auth;
using Lingodzilla.Common.DTOs.User;
using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Application.MappingProfiles;

public class UserProfile : Profile
{
    public UserProfile()
    {
        CreateMap<SignupDto, User>();
        CreateMap<User, UserDto>();
    }
}