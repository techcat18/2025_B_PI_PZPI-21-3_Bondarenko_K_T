﻿using AutoMapper;
using Lingodzilla.Common.DTOs.Exercise;
using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Application.MappingProfiles;

public class ExerciseProfile : Profile
{
    public ExerciseProfile()
    {
        CreateMap<Exercise, ExerciseDto>();
        CreateMap<CreateExerciseDto, Exercise>();

        CreateMap<ExerciseType, ExerciseTypeDto>();

        CreateMap<ExerciseOption, ExerciseOptionDto>();
    }
}