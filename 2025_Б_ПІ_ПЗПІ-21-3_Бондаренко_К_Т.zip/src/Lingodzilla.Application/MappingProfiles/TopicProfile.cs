﻿using AutoMapper;
using Lingodzilla.Common.DTOs.Topic;
using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Application.MappingProfiles;

public class TopicProfile : Profile
{
    public TopicProfile()
    {
        CreateMap<Topic, TopicDto>();
    }
}