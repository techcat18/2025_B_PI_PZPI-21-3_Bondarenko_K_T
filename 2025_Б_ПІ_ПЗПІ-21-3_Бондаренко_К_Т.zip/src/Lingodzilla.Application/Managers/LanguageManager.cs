﻿using AutoMapper;
using Lingodzilla.Abstractions.Application.Managers;
using Lingodzilla.Abstractions.Persistence;
using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Common.DTOs.Language;

namespace Lingodzilla.Application.Managers;

public class LanguageManager : ILanguageManager
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;

    public LanguageManager(
        IUnitOfWork unitOfWork, 
        IMapper mapper)
    {
        _unitOfWork = unitOfWork;
        _mapper = mapper;
    }

    public async Task<IEnumerable<LanguageDto>> GetLanguagesAsync(
        CancellationToken cancellationToken = default)
    {
        var languages = await _unitOfWork
            .GetRepository<ILanguageRepository>()
            .GetAllAsync(cancellationToken);
        return _mapper.Map<IEnumerable<LanguageDto>>(languages);
    }
}