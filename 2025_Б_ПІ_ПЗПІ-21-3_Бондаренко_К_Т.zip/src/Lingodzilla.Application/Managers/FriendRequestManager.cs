﻿using AutoMapper;
using Lingodzilla.Abstractions.Application.Managers;
using Lingodzilla.Abstractions.Infrastructure.Services;
using Lingodzilla.Abstractions.Persistence;
using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Common.DTOs.FriendRequest;
using Lingodzilla.Domain.Entities;
using Lingodzilla.Domain.Enums;

namespace Lingodzilla.Application.Managers;

public class FriendRequestManager : IFriendRequestManager
{
    private readonly IUserRepository _userRepository;
    private readonly IUnitOfWork _unitOfWork;
    private readonly IContextAccessor _contextAccessor;
    private readonly IMapper _mapper;

    public FriendRequestManager(
        IUserRepository userRepository,
        IUnitOfWork unitOfWork, 
        IContextAccessor contextAccessor, 
        IMapper mapper)
    {
        _userRepository = userRepository;
        _unitOfWork = unitOfWork;
        _contextAccessor = contextAccessor;
        _mapper = mapper;
    }
    
    public async Task<IEnumerable<FriendRequestDto>> GetFriendRequestsAsync(
        CancellationToken cancellationToken = default)
    {
        var friendRequests = await _unitOfWork
            .GetRepository<IFriendRequestRepository>()
            .GetPendingByAddresseeIdAsync(_contextAccessor.CurrentUserId, cancellationToken);

        return _mapper.Map<IEnumerable<FriendRequestDto>>(friendRequests);
    }
    public async Task SendFriendRequestAsync(
        SendFriendRequestDto sendFriendRequestDto,
        CancellationToken cancellationToken = default)
    {
        if (_contextAccessor.CurrentUserId == sendFriendRequestDto.ToUserId)
        {
            throw new ApplicationException("You cannot send a friend request to yourself");
        }

        var addressee = await _userRepository
            .GetByIdAsync(sendFriendRequestDto.ToUserId, cancellationToken);
        if (addressee is null)
        {
            throw new ApplicationException("User was not found");
        }
        
        var requestExists = await _unitOfWork
            .GetRepository<IFriendRequestRepository>()
            .GetByRequesterAndAddresseeIdsAsync(_contextAccessor.CurrentUserId, sendFriendRequestDto.ToUserId, cancellationToken);
        if (requestExists is not null)
        {
            throw new ApplicationException("Friend request already exists");
        }

        var friendRequest = new FriendRequest
        {
            RequesterId = _contextAccessor.CurrentUserId,
            AddresseeId = sendFriendRequestDto.ToUserId,
            Status = FriendRequestStatus.Pending
        };
        
        await _unitOfWork
            .GetRepository<IFriendRequestRepository>()
            .AddAsync(friendRequest, cancellationToken);

        await _unitOfWork.SaveChangesAsync(cancellationToken);
    }

    public async Task RespondToFriendRequestAsync(
        Guid requestId, 
        RespondToFriendRequestDto respondToFriendRequestDto,
        CancellationToken cancellationToken = default)
    {
        var friendRequest = await _unitOfWork
            .GetRepository<IFriendRequestRepository>()
            .GetByIdAsync(requestId, cancellationToken);
        if (friendRequest?.Status is not FriendRequestStatus.Pending)
        {
            throw new ApplicationException("Friend request was not found");
        }

        if (friendRequest.AddresseeId != _contextAccessor.CurrentUserId)
        {
            throw new ApplicationException("This friend request was not sent to you");
        }
        
        friendRequest.Status = respondToFriendRequestDto.Accepted 
            ? FriendRequestStatus.Accepted 
            : FriendRequestStatus.Declined;
        friendRequest.RespondedAt = DateTime.UtcNow;

        _unitOfWork
            .GetRepository<IFriendRequestRepository>()
            .Update(friendRequest);
        
        await _unitOfWork.SaveChangesAsync(cancellationToken);
    }
}