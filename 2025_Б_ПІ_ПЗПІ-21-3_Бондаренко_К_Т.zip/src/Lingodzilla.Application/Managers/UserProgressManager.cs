﻿using AutoMapper;
using Lingodzilla.Abstractions.Application.Managers;
using Lingodzilla.Abstractions.Persistence;
using Lingodzilla.Common.DTOs.UserProgress;

namespace Lingodzilla.Application.Managers;

public class UserProgressManager : IUserProgressManager
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;

    public UserProgressManager(IUnitOfWork unitOfWork, IMapper mapper)
    {
        _unitOfWork = unitOfWork;
        _mapper = mapper;
    }

    public async Task<UserProgressDto> GetUserProgressAsync(
        Guid userId, 
        Guid lessonId, 
        CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public async Task<UserProgressDto> CreateUserProgressAsync(
        Guid userId,
        CreateUserProgressDto createUserProgressDto, 
        CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }
    
    public async Task<UserProgressDto> UpdateUserProgressAsync(
        Guid userId,
        Guid id, 
        UpdateUserProgressDto updateUserProgressDto, 
        CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }
}