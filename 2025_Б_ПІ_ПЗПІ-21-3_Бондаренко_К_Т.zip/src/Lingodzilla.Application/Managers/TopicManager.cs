﻿using AutoMapper;
using Lingodzilla.Abstractions.Application.Managers;
using Lingodzilla.Abstractions.Persistence;
using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Common.DTOs.Topic;

namespace Lingodzilla.Application.Managers;

public class TopicManager : ITopicManager
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;

    public TopicManager(
        IUnitOfWork unitOfWork, 
        IMapper mapper)
    {
        _unitOfWork = unitOfWork;
        _mapper = mapper;
    }

    public async Task<IEnumerable<TopicDto>> GetTopicsAsync(
        CancellationToken cancellationToken = default)
    {
        var topics = await _unitOfWork
            .GetRepository<ITopicRepository>()
            .GetAllAsync(cancellationToken);
        return _mapper.Map<IEnumerable<TopicDto>>(topics);
    }
}