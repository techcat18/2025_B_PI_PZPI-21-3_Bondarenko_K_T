﻿using AutoMapper;
using Lingodzilla.Abstractions.Application.Managers;
using Lingodzilla.Abstractions.Infrastructure.Services;
using Lingodzilla.Abstractions.Persistence;
using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Common.DTOs.Exercise;
using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Application.Managers;

public class ExerciseManager : IExerciseManager
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;
    private readonly IContextAccessor _contextAccessor;

    public ExerciseManager(
        IUnitOfWork unitOfWork, 
        IMapper mapper, 
        IContextAccessor contextAccessor)
    {
        _unitOfWork = unitOfWork;
        _mapper = mapper;
        _contextAccessor = contextAccessor;
    }

    public async Task<IEnumerable<ExerciseDto>> GetExercisesByLessonIdAsync(
        Guid lessonId, 
        CancellationToken cancellationToken = default)
    {
        var exercises = await _unitOfWork
            .GetRepository<IExerciseRepository>()
            .GetByLessonIdAsync(lessonId, cancellationToken);
        return _mapper.Map<IEnumerable<ExerciseDto>>(exercises);
    }

    public async Task<IEnumerable<ExerciseTypeDto>> GetExerciseTypesAsync(
        CancellationToken cancellationToken = default)
    {
        var exerciseTypes = await _unitOfWork
            .GetRepository<IExerciseTypeRepository>()
            .GetAllAsync(cancellationToken);
        return _mapper.Map<IEnumerable<ExerciseTypeDto>>(exerciseTypes);
    }

    public async Task<ExerciseDto> GetExerciseAsync(
        Guid id, 
        CancellationToken cancellationToken = default)
    {
        var exercise = await _unitOfWork
            .GetRepository<IExerciseRepository>()
            .GetByIdAsync(id, cancellationToken);
        if (exercise is null)
        {
            throw new ApplicationException("Exercise not found");
        }

        return _mapper.Map<ExerciseDto>(exercise);
    }
    
    public async Task<ExerciseDto> CreateExerciseAsync(
        CreateExerciseDto createExerciseDto,
        CancellationToken cancellationToken = default)
    {
        var exercise = _mapper.Map<Exercise>(createExerciseDto);

        await _unitOfWork
            .GetRepository<IExerciseRepository>()
            .AddAsync(exercise, cancellationToken);
        
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return _mapper.Map<ExerciseDto>(exercise);
    }

    public async Task<ExerciseDto> UpdateExerciseAsync(
        Guid id, 
        UpdateExerciseDto updateExerciseDto, 
        CancellationToken cancellationToken = default)
    {
        var exercise = await _unitOfWork
            .GetRepository<IExerciseRepository>()
            .GetByIdAsync(id, cancellationToken);
        if (exercise is null)
        {
            throw new ApplicationException("Exercise not found");
        }

        exercise.Question = updateExerciseDto.Question;
        exercise.CorrectAnswer = updateExerciseDto.CorrectAnswer;
        exercise.ExerciseTypeId = updateExerciseDto.ExerciseTypeId;
        exercise.Explanation = updateExerciseDto.Explanation;

        _unitOfWork
            .GetRepository<IExerciseRepository>()
            .Update(exercise);

        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return _mapper.Map<ExerciseDto>(exercise);
    }

    public async Task DeleteExerciseAsync(
        Guid id, 
        CancellationToken cancellationToken = default)
    {
        var exercise = await _unitOfWork
            .GetRepository<IExerciseRepository>()
            .GetByIdAsync(id, cancellationToken);
        if (exercise is null)
        {
            throw new ApplicationException("Exercise not found");
        }

        _unitOfWork
            .GetRepository<IExerciseRepository>()
            .Delete(exercise);
        
        await _unitOfWork.SaveChangesAsync(cancellationToken);
    }

    public async Task<bool> DoExerciseAsync(
        Guid exerciseId,
        DoExerciseDto doExerciseDto, 
        CancellationToken cancellationToken = default)
    {
        var userId = _contextAccessor.CurrentUserId;

        var exercise = await _unitOfWork
            .GetRepository<IExerciseRepository>()
            .GetByIdAsync(exerciseId, cancellationToken);
        if (exercise is null)
        {
            throw new ApplicationException("Exercise was not found");
        }
        
        var lesson = await _unitOfWork
            .GetRepository<ILessonRepository>()
            .GetByIdAsync(exercise.LessonId, cancellationToken);
        if (lesson is null)
        {
            throw new ApplicationException("Lesson was not found");
        }

        var isCorrect = string.Equals(
            doExerciseDto.SubmittedAnswer.Trim(),
            exercise.CorrectAnswer?.Trim(),
            StringComparison.OrdinalIgnoreCase);

        if (lesson.Course.UserId != _contextAccessor.CurrentUserId)
        {
            await RecordAttemptAsync(userId, exerciseId, doExerciseDto.SubmittedAnswer, isCorrect, cancellationToken);
            var progress = await UpdateExerciseProgressAsync(userId, exerciseId, isCorrect, cancellationToken);
            await UpdateLessonProgressAsync(userId, exercise.LessonId, cancellationToken);

            if (isCorrect && progress.IsCompleted)
            {
                await CreateFlashcardsForExerciseAsync(userId, exercise, cancellationToken);
            }

            await _unitOfWork.SaveChangesAsync(cancellationToken);
        }
        
        return isCorrect;
    }

    private async Task RecordAttemptAsync(Guid userId, Guid exerciseId, string answer, bool isCorrect, CancellationToken cancellationToken)
    {
        var attempts = await _unitOfWork
            .GetRepository<IUserExerciseAttemptRepository>()
            .GetAsync(userId, exerciseId, cancellationToken);

        var attempt = new UserExerciseAttempt
        {
            UserId = userId,
            ExerciseId = exerciseId,
            SubmittedAnswer = answer,
            IsCorrect = isCorrect,
            SubmittedAt = DateTime.UtcNow,
            AttemptNumber = attempts.Count() + 1
        };

        await _unitOfWork
            .GetRepository<IUserExerciseAttemptRepository>()
            .AddAsync(attempt, cancellationToken);
    }

    private async Task<UserExerciseProgress> UpdateExerciseProgressAsync(Guid userId, Guid exerciseId, bool isCorrect, CancellationToken cancellationToken)
    {
        var repo = _unitOfWork.GetRepository<IUserExerciseProgressRepository>();
        var progress = await repo.FindAsync(userId, exerciseId, cancellationToken);

        if (progress == null)
        {
            progress = new UserExerciseProgress
            {
                UserId = userId,
                ExerciseId = exerciseId,
                TotalAttempts = 1,
                IsCompleted = isCorrect,
                FirstCorrectAt = isCorrect ? DateTime.UtcNow : null,
                LastAttemptAt = DateTime.UtcNow
            };
            await repo.AddAsync(progress, cancellationToken);
        }
        else
        {
            progress.TotalAttempts += 1;
            progress.LastAttemptAt = DateTime.UtcNow;

            if (isCorrect && !progress.IsCompleted)
            {
                progress.IsCompleted = true;
                progress.FirstCorrectAt = DateTime.UtcNow;
            }

            repo.Update(progress);
        }

        return progress;
    }

    private async Task UpdateLessonProgressAsync(Guid userId, Guid lessonId, CancellationToken cancellationToken)
    {
        var lessonRepo = _unitOfWork.GetRepository<ILessonRepository>();
        var lesson = await lessonRepo.GetByIdAsync(lessonId, cancellationToken);
        if (lesson is null)
        {
            throw new ApplicationException("Lesson was not found");
        }

        var exerciseIds = lesson.Exercises.Select(e => e.Id).ToList();
        var completed = await _unitOfWork
            .GetRepository<IUserExerciseProgressRepository>()
            .GetCompletedAsync(userId, exerciseIds, cancellationToken);

        var userLessonProgressRepo = _unitOfWork.GetRepository<IUserLessonProgressRepository>();
        var progress = await userLessonProgressRepo.FindAsync(userId, lessonId, cancellationToken);

        var total = lesson.Exercises.Count;
        var completedCount = completed.Count();

        if (progress == null)
        {
            progress = new UserLessonProgress
            {
                UserId = userId,
                LessonId = lessonId,
                TotalExercises = total,
                CompletedExercises = completedCount,
                IsCompleted = completedCount == total,
                CompletedAt = completedCount == total ? DateTime.UtcNow : null
            };

            await userLessonProgressRepo.AddAsync(progress, cancellationToken);
        }
        else
        {
            progress.TotalExercises = total;
            progress.CompletedExercises = completedCount;
            progress.IsCompleted = completedCount == total;
            progress.CompletedAt = progress.IsCompleted ? DateTime.UtcNow : null;

            userLessonProgressRepo.Update(progress);
        }
    }

    private async Task CreateFlashcardsForExerciseAsync(Guid userId, Exercise exercise, CancellationToken cancellationToken)
    {
        var flashcardRepo = _unitOfWork.GetRepository<IFlashcardRepository>();
        var existingFlashcards = await flashcardRepo.GetByUserAndExerciseAsync(userId, exercise.Id, cancellationToken);
        var existingWordIds = existingFlashcards.Select(f => f.WordId).ToHashSet();

        foreach (var word in exercise.Words)
        {
            if (existingWordIds.Contains(word.Id))
                continue;

            var flashcard = new Flashcard
            {
                UserId = userId,
                WordId = word.Id,
                ExerciseId = exercise.Id,
                IsAutoGenerated = true,
                CreatedAt = DateTime.UtcNow
            };

            await flashcardRepo.AddAsync(flashcard, cancellationToken);
        }
    }
}