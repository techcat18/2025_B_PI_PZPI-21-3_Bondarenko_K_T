﻿using AutoMapper;
using Lingodzilla.Abstractions.Application.Managers;
using Lingodzilla.Abstractions.Persistence;
using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Common.DTOs.Lesson;
using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Application.Managers;

public class LessonManager : ILessonManager
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;

    public LessonManager(
        IUnitOfWork unitOfWork, 
        IMapper mapper)
    {
        _unitOfWork = unitOfWork;
        _mapper = mapper;
    }

    public async Task<IEnumerable<LessonDto>> GetByCourseAsync(
        Guid courseId, 
        CancellationToken cancellationToken = default)
    {
        var course = await _unitOfWork
            .GetRepository<ICourseRepository>()
            .GetByIdAsync(courseId, cancellationToken);
        if (course is null)
        {
            throw new ApplicationException("Course was not found");
        }
        
        var lessons = await _unitOfWork
            .GetRepository<ILessonRepository>()
            .GetByCourseAsync(course.Id, cancellationToken);

        return _mapper.Map<IEnumerable<LessonDto>>(lessons);
    }

    public async Task<LessonDto> GetLessonAsync(
        Guid id, 
        CancellationToken cancellationToken = default)
    {
        var lesson = await _unitOfWork
            .GetRepository<ILessonRepository>()
            .GetByIdAsync(id, cancellationToken);
        if (lesson is null)
        {
            throw new ApplicationException("Lesson was not found");
        }

        return _mapper.Map<LessonDto>(lesson);
    }

    public async Task<LessonDto> CreateLessonAsync(
        CreateLessonDto createLessonDto, 
        CancellationToken cancellationToken = default)
    {
        var lesson = _mapper.Map<Lesson>(createLessonDto);
        
        var course = await _unitOfWork
            .GetRepository<ICourseRepository>()
            .GetByIdAsync(lesson.CourseId, cancellationToken);
        if (course is null)
        {
            throw new ApplicationException("Course was not found");
        }
        
        await _unitOfWork
            .GetRepository<ILessonRepository>()
            .AddAsync(lesson, cancellationToken);

        await _unitOfWork.SaveChangesAsync(cancellationToken);
        
        return _mapper.Map<LessonDto>(lesson);
    }
    
    public async Task<LessonDto> UpdateLessonAsync(Guid id, 
        UpdateLessonDto updateLessonDto, 
        CancellationToken cancellationToken = default)
    {
        var lesson = await _unitOfWork
            .GetRepository<ILessonRepository>()
            .GetByIdAsync(id, cancellationToken);
        if (lesson is null)
        {
            throw new ApplicationException("Lesson was not found");
        }

        lesson.Name = updateLessonDto.Name;
        lesson.OrderIndex = updateLessonDto.OrderIndex;

        _unitOfWork
            .GetRepository<ILessonRepository>()
            .Update(lesson);
        
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return _mapper.Map<LessonDto>(lesson);
    }

    public async Task DeleteLessonAsync(
        Guid id, 
        CancellationToken cancellationToken = default)
    {
        var lesson = await _unitOfWork
            .GetRepository<ILessonRepository>()
            .GetByIdAsync(id, cancellationToken);
        if (lesson is null)
        {
            throw new ApplicationException("Lesson was not found");
        }

        _unitOfWork
            .GetRepository<ILessonRepository>()
            .Delete(lesson);

        await _unitOfWork.SaveChangesAsync(cancellationToken);
    }
}