﻿using AutoMapper;
using Lingodzilla.Abstractions.Application.Managers;
using Lingodzilla.Abstractions.Infrastructure.Services;
using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Common.DTOs.User;

namespace Lingodzilla.Application.Managers;

public class UserManager : IUserManager
{
    private readonly IUserRepository _userRepository;
    private readonly IContextAccessor _contextAccessor;
    private readonly IMapper _mapper;

    public UserManager(
        IUserRepository userRepository,
        IContextAccessor contextAccessor, 
        IMapper mapper)
    {
        _userRepository = userRepository;
        _contextAccessor = contextAccessor;
        _mapper = mapper;
    }
    
    public async Task<IEnumerable<UserDto>> GetUsersAsync(
        CancellationToken cancellationToken = default)
    {
        var users = await _userRepository.GetAsync(cancellationToken);
        return _mapper.Map<IEnumerable<UserDto>>(users);
    }

    public async Task<IEnumerable<UserDto>> GetFriendsAsync(
        CancellationToken cancellationToken = default)
    {
        var friends = await _userRepository.GetFriendsAsync(_contextAccessor.CurrentUserId, cancellationToken);
        return _mapper.Map<IEnumerable<UserDto>>(friends);
    }

    public async Task<UserDto?> GetCurrentUserAsync(
        CancellationToken cancellationToken = default)
    {
        var user = await _userRepository.GetByIdAsync(_contextAccessor.CurrentUserId, cancellationToken);
        return _mapper.Map<UserDto>(user);
    }

    public async Task<UserDto> UpdateUserAsync(
        UpdateUserDto updateUserDto, 
        CancellationToken cancellationToken = default)
    {
        var user = await _userRepository.GetByIdAsync(_contextAccessor.CurrentUserId, cancellationToken);
        if (user is null)
        {
            throw new ApplicationException("User was not found");
        }

        user.PhoneNumber = updateUserDto.PhoneNumber;
        user.SendReminders = updateUserDto.SendReminders;

        _userRepository.Update(user);
        
        await _userRepository.SaveChangesAsync(cancellationToken);
        
        return _mapper.Map<UserDto>(user);
    }

    public Task UpdateUserPreferencesAsync(
        UpdateUserPreferencesDto updateUserPreferencesDto,
        CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }
}