﻿using AutoMapper;
using Lingodzilla.Abstractions.Application.Managers;
using Lingodzilla.Abstractions.Infrastructure.Services;
using Lingodzilla.Abstractions.Persistence;
using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Common.DTOs.Course;
using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Application.Managers;

public class CourseManager : ICourseManager
{
    private readonly IUnitOfWork _unitOfWork;
    private readonly IMapper _mapper;
    private readonly IContextAccessor _contextAccessor;

    public CourseManager(
        IUnitOfWork unitOfWork, 
        IMapper mapper, 
        IContextAccessor contextAccessor)
    {
        _unitOfWork = unitOfWork;
        _mapper = mapper;
        _contextAccessor = contextAccessor;
    }

    public async Task<IEnumerable<CourseDto>> GetCoursesAsync(
        CancellationToken cancellationToken = default)
    {
        var courses = await _unitOfWork
            .GetRepository<ICourseRepository>()
            .GetAllAsync(cancellationToken);
        return _mapper.Map<IEnumerable<CourseDto>>(courses);
    }

    public async Task<CourseDto> GetCourseAsync(
        Guid id, 
        CancellationToken cancellationToken = default)
    {
        var course = await _unitOfWork
            .GetRepository<ICourseRepository>()
            .GetByIdAsync(id, cancellationToken);
        if (course is null)
        {
            throw new ApplicationException("Course was not found");
        }

        return _mapper.Map<CourseDto>(course);
    }

    public async Task<CourseDto> CreateCourseAsync(
        CreateCourseDto createCourseDto, 
        CancellationToken cancellationToken = default)
    {
        var course = _mapper.Map<Course>(createCourseDto);

        course.UserId = _contextAccessor.CurrentUserId;
        
        await _unitOfWork
            .GetRepository<ICourseRepository>()
            .AddAsync(course, cancellationToken);

        await _unitOfWork.SaveChangesAsync(cancellationToken);
        
        return _mapper.Map<CourseDto>(course);
    }

    public async Task<CourseDto> UpdateCourseAsync(
        Guid id, 
        UpdateCourseDto updateCourseDto, 
        CancellationToken cancellationToken = default)
    {
        var course = await _unitOfWork
            .GetRepository<ICourseRepository>()
            .GetByIdAsync(id, cancellationToken);
        if (course is null)
        {
            throw new ApplicationException("Course was not found");
        }

        if (course.UserId != _contextAccessor.CurrentUserId)
        {
            throw new ApplicationException("You are not able to edit this course");
        }
        
        course.Name = updateCourseDto.Name;
        course.Description = updateCourseDto.Description;
        course.LanguageId = updateCourseDto.LanguageId;
        course.TargetLanguageId = updateCourseDto.TargetLanguageId;

        _unitOfWork
            .GetRepository<ICourseRepository>()
            .Update(course);
        
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return _mapper.Map<CourseDto>(course);
    }

    public async Task DeleteCourseAsync(Guid id, CancellationToken cancellationToken = default)
    {
        var course = await _unitOfWork
            .GetRepository<ICourseRepository>()
            .GetByIdAsync(id, cancellationToken);
        if (course is null)
        {
            throw new ApplicationException("Course was not found");
        }

        if (course.UserId != _contextAccessor.CurrentUserId)
        {
            throw new ApplicationException("You are not able to delete this course");
        }
        
        _unitOfWork
            .GetRepository<ICourseRepository>()
            .Delete(course);

        await _unitOfWork.SaveChangesAsync(cancellationToken);
    }
}