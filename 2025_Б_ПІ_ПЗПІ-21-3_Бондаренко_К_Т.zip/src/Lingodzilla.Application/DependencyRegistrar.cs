﻿using Lingodzilla.Abstractions.Application.Managers;
using Lingodzilla.Abstractions.Application.Services;
using Lingodzilla.Application.Managers;
using Lingodzilla.Application.MappingProfiles;
using Lingodzilla.Application.Services;
using Lingodzilla.Common.Options;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Lingodzilla.Application;

public static class DependencyRegistrar
{
    public static void ConfigureApplicationDependencies(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.ConfigureOptions(configuration);
        services.ConfigureManagers();
        services.ConfigureServices(); 
        services.ConfigureAutomapper();
    }

    private static void ConfigureOptions(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        services.Configure<JwtSettings>(configuration.GetSection(nameof(JwtSettings)));
    }

    private static void ConfigureManagers(
        this IServiceCollection services)
    {
        services.AddScoped<ILanguageManager, LanguageManager>();
        services.AddScoped<ICourseManager, CourseManager>();
        services.AddScoped<ILessonManager, LessonManager>();
        services.AddScoped<ITopicManager, TopicManager>();
        services.AddScoped<IExerciseManager, ExerciseManager>();
        services.AddScoped<IUserManager, UserManager>();
        services.AddScoped<IFriendRequestManager, FriendRequestManager>();
        services.AddScoped<IFlashcardManager, FlashcardManager>();
    }
    
    private static void ConfigureServices(
        this IServiceCollection services)
    {
        services.AddScoped<IJwtService, JwtService>();
        services.AddScoped<IAuthService, AuthService>();
        services.AddScoped<ILeaderboardService, LeaderboardService>();
    }

    private static void ConfigureAutomapper(
        this IServiceCollection services)
    {
        services.AddAutoMapper(typeof(LanguageProfile).Assembly);
    }
}