﻿namespace Lingodzilla.Domain.Entities;

public class Exercise : BaseEntity
{
    public string Question { get; set; } = null!;
    public string? AudioUrl { get; set; }
    public string? CorrectAnswer { get; set; }
    public string? Explanation { get; set; }
    
    public Guid LessonId { get; set; }
    public Lesson Lesson { get; set; } = null!;

    public Guid ExerciseTypeId { get; set; }
    public ExerciseType ExerciseType { get; set; } = null!;

    public ICollection<Word> Words { get; set; } = new List<Word>();
    public ICollection<ExerciseOption> Options { get; set; } = new List<ExerciseOption>();
}