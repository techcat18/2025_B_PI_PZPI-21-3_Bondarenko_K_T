﻿using System.Text.Json.Serialization;

namespace Lingodzilla.Domain.Entities;

public class ExerciseOption : BaseEntity
{
    public string OptionText { get; set; } = null!;
    public bool IsCorrect { get; set; }
    
    public Guid ExerciseId { get; set; }
    
    [JsonIgnore]
    public Exercise? Exercise { get; set; }
}