﻿namespace Lingodzilla.Domain.Entities;

public class UserPreferenceTopics
{
    public Guid UserPreferencesUserId { get; set; }
    public Guid TopicId { get; set; }
}