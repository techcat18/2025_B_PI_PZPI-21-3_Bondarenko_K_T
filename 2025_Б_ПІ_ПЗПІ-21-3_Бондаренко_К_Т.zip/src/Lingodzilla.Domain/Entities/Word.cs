﻿namespace Lingodzilla.Domain.Entities;

public class Word : BaseEntity
{
    public string Text { get; set; } = null!;
    public string? Translation { get; set; }
    public string? PartOfSpeech { get; set; }
    public string? ExampleSentence { get; set; }
    
    public ICollection<Exercise> Exercises { get; set; } = new List<Exercise>();
}