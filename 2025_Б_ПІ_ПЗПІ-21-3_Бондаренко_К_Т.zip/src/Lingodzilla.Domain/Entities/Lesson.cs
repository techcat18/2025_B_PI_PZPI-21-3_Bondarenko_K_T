﻿namespace Lingodzilla.Domain.Entities;

public class Lesson : BaseEntity
{
    public string Name { get; set; } = null!;
    public int OrderIndex { get; set; }

    public Guid CourseId { get; set; }
    public Course Course { get; set; } = null!;

    public ICollection<Exercise> Exercises { get; set; } = new List<Exercise>();
}