﻿namespace Lingodzilla.Domain.Entities;

public class UserPreferences
{
    public Guid UserId { get; set; }
    public User User { get; set; } = null!;
    
    public List<ExerciseType> PreferredExerciseTypes { get; set; } = [];
    
    public ICollection<Topic> PreferredTopics { get; set; } = [];
    //public ICollection<Word> PreferredWords { get; set; } = [];
}