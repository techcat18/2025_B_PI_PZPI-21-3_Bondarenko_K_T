﻿namespace Lingodzilla.Domain.Entities;

public class UserProgress : BaseEntity
{
    public int Score { get; set; }
    public DateTime CompletedAt { get; set; }

    public Guid UserId { get; set; }
    public User User { get; set; } = null!;

    public Guid LessonId { get; set; }
    public Lesson Lesson { get; set; } = null!;
}