﻿namespace Lingodzilla.Domain.Entities;

public class Translation : BaseEntity
{
    public string Value { get; set; } = null!;

    public Guid LanguageId { get; set; }
    public Language Language { get; set; } = null!;

    public Guid WordId { get; set; }
    public Word Word { get; set; } = null!;
}