﻿using Microsoft.AspNetCore.Identity;

namespace Lingodzilla.Domain.Entities;

public class Role : IdentityRole<Guid>
{
}