﻿namespace Lingodzilla.Domain.Entities;

public class Course : BaseEntity
{
    public string Name { get; set; } = null!;
    public string? Description { get; set; }
    
    public Guid LanguageId { get; set; }
    public Language Language { get; set; } = null!;
    
    public Guid TargetLanguageId { get; set; }
    public Language TargetLanguage { get; set; } = null!;
    
    public Guid? UserId { get; set; }
    public User? User { get; set; } 
    
    public ICollection<Lesson> Lessons { get; set; } = new List<Lesson>();
}