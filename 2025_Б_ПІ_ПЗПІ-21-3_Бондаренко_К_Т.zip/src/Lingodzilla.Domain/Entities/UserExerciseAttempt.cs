﻿namespace Lingodzilla.Domain.Entities;

public class UserExerciseAttempt : BaseEntity
{
    public Guid UserId { get; set; }
    public User User { get; set; } = null!;

    public Guid ExerciseId { get; set; }
    public Exercise Exercise { get; set; } = null!;

    public string SubmittedAnswer { get; set; } = null!;
    public bool IsCorrect { get; set; }
    public DateTime SubmittedAt { get; set; }

    public int AttemptNumber { get; set; } 
}