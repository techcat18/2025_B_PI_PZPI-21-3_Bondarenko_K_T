﻿namespace Lingodzilla.Domain.Entities;

public class UserLessonProgress : BaseEntity
{
    public Guid UserId { get; set; }
    public User User { get; set; } = null!;
    
    public Guid LessonId { get; set; }
    public Lesson Lesson { get; set; } = null!;

    public int TotalExercises { get; set; }
    public int CompletedExercises { get; set; }
    public bool IsCompleted { get; set; }
    public DateTime? CompletedAt { get; set; }
}