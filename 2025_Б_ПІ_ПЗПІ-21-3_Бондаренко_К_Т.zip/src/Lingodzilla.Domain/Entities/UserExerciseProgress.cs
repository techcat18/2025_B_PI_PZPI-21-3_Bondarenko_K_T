﻿namespace Lingodzilla.Domain.Entities;

public class UserExerciseProgress : BaseEntity
{
    public Guid UserId { get; set; }
    public User User { get; set; } = null!;
    
    public Guid ExerciseId { get; set; }
    public Exercise Exercise { get; set; } = null!;

    public int TotalAttempts { get; set; }
    public bool IsCompleted { get; set; }
    public DateTime? FirstCorrectAt { get; set; }
    public DateTime? LastAttemptAt { get; set; }
}