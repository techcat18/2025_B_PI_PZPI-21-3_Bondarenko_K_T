﻿namespace Lingodzilla.Domain.Entities;

public class Language : BaseEntity
{
    public string Name { get; init; } = null!;
    public string Code { get; init; } = null!;
}