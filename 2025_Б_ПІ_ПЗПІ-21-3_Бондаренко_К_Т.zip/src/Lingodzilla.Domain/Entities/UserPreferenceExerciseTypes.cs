﻿namespace Lingodzilla.Domain.Entities;

public class UserPreferenceExerciseTypes
{
    public Guid UserPreferencesUserId { get; set; }
    public int ExerciseTypeId { get; set; }
}