﻿namespace Lingodzilla.Domain.Entities;

public class ExerciseWord
{
    public Guid ExerciseId { get; set; }
    public Exercise Exercise { get; set; } = null!;

    public Guid WordId { get; set; }
    public Word Word { get; set; } = null!;
}