﻿namespace Lingodzilla.Domain.Entities;

public class ExerciseType : BaseEntity
{
    public string Name { get; init; } = null!;
    public string? Description { get; init; }
}