﻿using Microsoft.AspNetCore.Identity;

namespace Lingodzilla.Domain.Entities;

public class User : IdentityUser<Guid>
{
    public string? PhoneNumber { get; set; }
    public bool SendReminders { get; set; }
    public long? TelegramChatId { get; set; }
    
    public UserPreferences Preferences { get; init; } = null!;
    
    public ICollection<FriendRequest> SentFriendRequests { get; init; } = new List<FriendRequest>();
    public ICollection<FriendRequest> ReceivedFriendRequests { get; init; } = new List<FriendRequest>();
    public ICollection<UserExerciseAttempt> ExerciseAttempts { get; init; } = new List<UserExerciseAttempt>();
    public ICollection<UserExerciseProgress> ExerciseProgresses { get; init; } = new List<UserExerciseProgress>();
    public ICollection<UserLessonProgress> LessonProgresses { get; init; } = new List<UserLessonProgress>();
}