﻿namespace Lingodzilla.Domain.Entities;

public class LeaderboardEntry
{
    public User User { get; init; } = null!;
    public double Score { get; init; }
}