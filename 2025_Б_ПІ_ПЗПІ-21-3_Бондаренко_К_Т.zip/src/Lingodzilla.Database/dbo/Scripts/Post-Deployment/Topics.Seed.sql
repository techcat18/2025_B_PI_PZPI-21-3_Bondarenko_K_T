﻿-- Core educational topics
INSERT INTO [dbo].[Topics] ([Id], [Name], [Description])
SELECT NEWID(), 'Culture', 'Explore traditions, customs, and social behaviors of various cultures.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Topics] WHERE [Name] = 'Culture');

INSERT INTO [dbo].[Topics] ([Id], [Name], [Description])
SELECT NEWID(), 'History', 'Learn about significant historical events, figures, and timelines.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Topics] WHERE [Name] = 'History');

INSERT INTO [dbo].[Topics] ([Id], [Name], [Description])
SELECT NEWID(), 'Geography', 'Understand countries, landmarks, climates, and maps.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Topics] WHERE [Name] = 'Geography');

-- Lifestyle & everyday topics
INSERT INTO [dbo].[Topics] ([Id], [Name], [Description])
SELECT NEWID(), 'Food & Cooking', 'Learn vocabulary and phrases about recipes, meals, and kitchen activities.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Topics] WHERE [Name] = 'Food & Cooking');

INSERT INTO [dbo].[Topics] ([Id], [Name], [Description])
SELECT NEWID(), 'Travel', 'Practice language for booking trips, navigating airports, and exploring destinations.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Topics] WHERE [Name] = 'Travel');

INSERT INTO [dbo].[Topics] ([Id], [Name], [Description])
SELECT NEWID(), 'Health', 'Talk about health, body parts, symptoms, and medical appointments.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Topics] WHERE [Name] = 'Health');

INSERT INTO [dbo].[Topics] ([Id], [Name], [Description])
SELECT NEWID(), 'Weather', 'Describe weather conditions and understand forecasts.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Topics] WHERE [Name] = 'Weather');

INSERT INTO [dbo].[Topics] ([Id], [Name], [Description])
SELECT NEWID(), 'Shopping', 'Use vocabulary for buying clothes, groceries, and other goods.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Topics] WHERE [Name] = 'Shopping');

-- Interests & entertainment
INSERT INTO [dbo].[Topics] ([Id], [Name], [Description])
SELECT NEWID(), 'Music', 'Talk about genres, instruments, concerts, and your favorite songs.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Topics] WHERE [Name] = 'Music');

INSERT INTO [dbo].[Topics] ([Id], [Name], [Description])
SELECT NEWID(), 'Movies', 'Discuss movie genres, actors, plotlines, and cinema vocabulary.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Topics] WHERE [Name] = 'Movies');

INSERT INTO [dbo].[Topics] ([Id], [Name], [Description])
SELECT NEWID(), 'Sport', 'Learn words and phrases for sports, teams, and physical activities.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Topics] WHERE [Name] = 'Sport');

INSERT INTO [dbo].[Topics] ([Id], [Name], [Description])
SELECT NEWID(), 'Technology', 'Understand terms related to gadgets, the internet, and innovations.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Topics] WHERE [Name] = 'Technology');

INSERT INTO [dbo].[Topics] ([Id], [Name], [Description])
SELECT NEWID(), 'Fashion', 'Talk about clothes, trends, and style expressions.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Topics] WHERE [Name] = 'Fashion');

-- Social & functional
INSERT INTO [dbo].[Topics] ([Id], [Name], [Description])
SELECT NEWID(), 'Jobs & Work', 'Discuss professions, office life, job interviews, and work routines.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Topics] WHERE [Name] = 'Jobs & Work');

INSERT INTO [dbo].[Topics] ([Id], [Name], [Description])
SELECT NEWID(), 'Relationships', 'Learn to talk about friends, family, dating, and social life.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Topics] WHERE [Name] = 'Relationships');

INSERT INTO [dbo].[Topics] ([Id], [Name], [Description])
SELECT NEWID(), 'Daily Routine', 'Describe everyday habits and time-based activities.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Topics] WHERE [Name] = 'Daily Routine');
