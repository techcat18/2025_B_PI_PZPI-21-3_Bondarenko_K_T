﻿
:r .\Languages.Seed.sql
:r .\Topics.Seed.sql
:r .\ExerciseTypes.Seed.sql