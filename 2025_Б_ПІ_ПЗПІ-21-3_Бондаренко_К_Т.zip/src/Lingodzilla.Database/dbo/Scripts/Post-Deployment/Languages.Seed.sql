﻿INSERT INTO [dbo].[Languages] ([Id], [Name], [Code])
SELECT NEWID(), 'English', 'en'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Languages] WHERE [Code] = 'en');

INSERT INTO [dbo].[Languages] ([Id], [Name], [Code])
SELECT NEWID(), 'Ukrainian', 'uk'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Languages] WHERE [Code] = 'uk');

INSERT INTO [dbo].[Languages] ([Id], [Name], [Code])
SELECT NEWID(), 'French', 'fr'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[Languages] WHERE [Code] = 'fr');