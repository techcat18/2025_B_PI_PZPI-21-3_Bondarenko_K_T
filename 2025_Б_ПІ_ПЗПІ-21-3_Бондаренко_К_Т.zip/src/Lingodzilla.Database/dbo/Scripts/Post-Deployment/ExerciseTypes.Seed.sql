﻿INSERT INTO [dbo].[ExerciseTypes] ([Id], [Name], [Description])
SELECT NEWID(), 'Multiple Choice', 'Choose the correct answer from several options.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[ExerciseTypes] WHERE [Name] = 'Multiple Choice');

INSERT INTO [dbo].[ExerciseTypes] ([Id], [Name], [Description])
SELECT NEWID(), 'Fill in the Blank', 'Complete the sentence by entering the missing word or phrase.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[ExerciseTypes] WHERE [Name] = 'Fill in the Blank');

INSERT INTO [dbo].[ExerciseTypes] ([Id], [Name], [Description])
SELECT NEWID(), 'Matching', 'Match words or phrases with their corresponding translations or images.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[ExerciseTypes] WHERE [Name] = 'Matching');

INSERT INTO [dbo].[ExerciseTypes] ([Id], [Name], [Description])
SELECT NEWID(), 'Speaking Practice', 'Practice pronunciation by repeating or constructing sentences.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[ExerciseTypes] WHERE [Name] = 'Speaking Practice');

INSERT INTO [dbo].[ExerciseTypes] ([Id], [Name], [Description])
SELECT NEWID(), 'Listening Comprehension', 'Listen to audio and answer questions about what you hear.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[ExerciseTypes] WHERE [Name] = 'Listening Comprehension');

INSERT INTO [dbo].[ExerciseTypes] ([Id], [Name], [Description])
SELECT NEWID(), 'Translation', 'Translate a sentence or phrase into another language.'
WHERE NOT EXISTS (SELECT 1 FROM [dbo].[ExerciseTypes] WHERE [Name] = 'Translation');
