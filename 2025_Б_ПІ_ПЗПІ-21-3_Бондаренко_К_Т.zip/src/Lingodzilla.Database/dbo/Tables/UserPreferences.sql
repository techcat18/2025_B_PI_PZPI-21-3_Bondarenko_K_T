﻿CREATE TABLE [dbo].[UserPreferences]
(
	UserId UNIQUEIDENTIFIER PRIMARY KEY,
    CONSTRAINT FK_UserPreferences_User FOREIGN KEY (UserId)
        REFERENCES AspNetUsers(Id) ON DELETE CASCADE
)
