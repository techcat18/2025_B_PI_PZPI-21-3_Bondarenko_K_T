﻿CREATE TABLE [dbo].[UserPreferenceTopics]
(
	UserPreferencesUserId UNIQUEIDENTIFIER NOT NULL,
    TopicId UNIQUEIDENTIFIER NOT NULL,
    PRIMARY KEY (UserPreferencesUserId, TopicId),
    CONSTRAINT FK_UserPreferences_Topics_UserPreferences FOREIGN KEY (UserPreferencesUserId)
        REFERENCES UserPreferences(UserId) ON DELETE CASCADE,
    CONSTRAINT FK_UserPreferences_Topics_Topics FOREIGN KEY (TopicId)
        REFERENCES Topics(Id) ON DELETE CASCADE
)
