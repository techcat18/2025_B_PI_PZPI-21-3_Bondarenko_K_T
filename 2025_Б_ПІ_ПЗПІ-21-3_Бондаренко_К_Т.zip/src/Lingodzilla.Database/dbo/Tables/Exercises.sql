﻿CREATE TABLE [dbo].[Exercises]
(
    [Id] UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    [Question] NVARCHAR(1000) NULL,
    [AudioUrl] NVARCHAR(1000) NULL,
    [CorrectAnswer] NVARCHAR(MAX) NOT NULL,
    [Explanation] NVARCHAR(MAX) NULL,

    [LessonId] UNIQUEIDENTIFIER NOT NULL,
    [ExerciseTypeId] UNIQUEIDENTIFIER NOT NULL,

    CONSTRAINT FK_Exercises_Lessons FOREIGN KEY ([LessonId]) REFERENCES [dbo].[Lessons]([Id]),
    CONSTRAINT FK_Exercises_ExerciseTypes FOREIGN KEY ([ExerciseTypeId]) REFERENCES [dbo].[ExerciseTypes]([Id])
);
