﻿CREATE TABLE [dbo].[ExerciseWords]
(
    [ExerciseId] UNIQUEIDENTIFIER NOT NULL,
    [WordId] UNIQUEIDENTIFIER NOT NULL,

    CONSTRAINT PK_ExerciseWords PRIMARY KEY ([ExerciseId], [WordId]),
    CONSTRAINT FK_ExerciseWords_Exercises FOREIGN KEY ([ExerciseId]) REFERENCES [dbo].[Exercises]([Id]) ON DELETE CASCADE,
    CONSTRAINT FK_ExerciseWords_Words FOREIGN KEY ([WordId]) REFERENCES [dbo].[Words]([Id]) ON DELETE CASCADE
);
