﻿CREATE TABLE [dbo].[FriendRequests](
    [Id] UNIQUEIDENTIFIER NOT NULL,
    [RequesterId] UNIQUEIDENTIFIER NOT NULL,
    [AddresseeId] UNIQUEIDENTIFIER NOT NULL,
    [Status] INT NOT NULL,
    [RequestedAt] DATETIME2 NOT NULL,
    [RespondedAt] DATETIME2 NULL,
    CONSTRAINT [PK_FriendRequests] PRIMARY KEY CLUSTERED 
    (
        [Id] ASC
    ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, 
            IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON),
    
    CONSTRAINT [FK_FriendRequests_Requester] FOREIGN KEY ([RequesterId])
        REFERENCES [dbo].[AspNetUsers] ([Id]) 
        ON DELETE NO ACTION,
        
    CONSTRAINT [FK_FriendRequests_Addressee] FOREIGN KEY ([AddresseeId])
        REFERENCES [dbo].[AspNetUsers] ([Id]) 
        ON DELETE NO ACTION
) ON [PRIMARY];
