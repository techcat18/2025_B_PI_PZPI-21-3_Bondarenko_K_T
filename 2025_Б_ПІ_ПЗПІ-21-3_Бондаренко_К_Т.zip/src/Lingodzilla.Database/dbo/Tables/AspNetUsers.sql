﻿CREATE TABLE [dbo].[AspNetUsers](
	[Id] UNIQUEIDENTIFIER NOT NULL,
	[FirstName] NVARCHAR(400),
	[LastName] NVARCHAR(400),
	[InvitationNote] NVARCHAR(max),
	[CompanyName] NVARCHAR (200),
	[JobTitle] NVARCHAR (200),
	[ProfilePictureUrl] NVARCHAR(1000) NULL,
    [CurrentAccountId] UNIQUEIDENTIFIER NULL,
	[Blocked] BIT,
	[AccessFailedCount] INT NOT NULL,
	[ConcurrencyStamp] NVARCHAR(max) NULL,
	[Email] NVARCHAR(256) NULL,
	[EmailConfirmed] BIT NOT NULL,
	[LockoutEnabled] BIT NOT NULL,
	[LockoutEnd] DATETIMEOFFSET(7) NULL,
	[NormalizedEmail] NVARCHAR(256) NULL,
	[NormalizedUserName] NVARCHAR(256) NULL,
	[PasswordHash] NVARCHAR(max) NULL,
	[PhoneNumber] NVARCHAR(max) NULL,
	[PhoneNumberConfirmed] BIT NOT NULL,
	[SecurityStamp] NVARCHAR(max) NULL,
	[TwoFactorEnabled] BIT NOT NULL,
	[UserName] NVARCHAR(256) NULL,
	[SendReminders] BIT NOT NULL CONSTRAINT DF_AspNetUsers_SendReminders DEFAULT 0,
	[TelegramChatId] BIGINT NULL,
	[CreatedAt] DATETIME NULL,
	[ModifiedAt] DATETIME NULL,
	[IsDeleted] BIT DEFAULT 0,
 CONSTRAINT [PK_AspNetUsers] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]