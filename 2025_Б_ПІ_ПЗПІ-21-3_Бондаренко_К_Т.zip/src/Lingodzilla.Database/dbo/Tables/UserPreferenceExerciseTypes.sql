﻿CREATE TABLE [dbo].[UserPreferenceExerciseTypes]
(
	UserPreferencesUserId UNIQUEIDENTIFIER NOT NULL,
    ExerciseTypeId UNIQUEIDENTIFIER NOT NULL,
    PRIMARY KEY (UserPreferencesUserId, ExerciseTypeId),
    CONSTRAINT FK_UserPreferences_ExerciseTypes_UserPreferences FOREIGN KEY (UserPreferencesUserId)
        REFERENCES UserPreferences(UserId) ON DELETE CASCADE,
    CONSTRAINT FK_UserPreferences_ExerciseTypes_ExerciseTypes FOREIGN KEY (ExerciseTypeId)
        REFERENCES ExerciseTypes(Id) ON DELETE CASCADE
)
