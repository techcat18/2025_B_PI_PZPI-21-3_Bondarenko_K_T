﻿CREATE TABLE [dbo].[Words]
(
    [Id] UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    [Text] NVARCHAR(255) NOT NULL,
    [Translation] NVARCHAR(1000) NULL,
    [PartOfSpeech] NVARCHAR(100) NULL,
    [ExampleSentence] NVARCHAR(1000) NULL
);
