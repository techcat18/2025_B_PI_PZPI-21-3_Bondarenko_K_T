﻿CREATE TABLE [dbo].[ExerciseOptions]
(
    [Id] UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    [ExerciseId] UNIQUEIDENTIFIER NOT NULL,
    [OptionText] NVARCHAR(1000) NOT NULL,
    [IsCorrect] BIT NOT NULL DEFAULT 0,

    CONSTRAINT FK_ExerciseOptions_Exercises FOREIGN KEY ([ExerciseId])
        REFERENCES [dbo].[Exercises]([Id]) ON DELETE CASCADE
);
