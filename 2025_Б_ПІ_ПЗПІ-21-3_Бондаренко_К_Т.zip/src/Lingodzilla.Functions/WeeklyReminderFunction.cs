﻿using Lingodzilla.Abstractions.Persistence.Repositories;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Logging;
using Telegram.Bot;

namespace Lingodzilla.Functions;

public class WeeklyReminderFunction
{
    private readonly IUserRepository _userRepository;
    private readonly TelegramBotClient _telegramBot;

    public WeeklyReminderFunction(IUserRepository userRepository)
    {
        _userRepository = userRepository;
        var token = Environment.GetEnvironmentVariable("TelegramBotToken")!;
        _telegramBot = new TelegramBotClient(token);
    }
    
    //[Function(nameof(WeeklyReminderFunction))]
    public async Task Run(
        [TimerTrigger("0 * * * * *")] TimerInfo myTimer, 
        FunctionContext context)
    {
        var logger = context.GetLogger(nameof(WeeklyReminderFunction));
        logger.LogInformation($"Weekly reminder started at {DateTime.UtcNow}");

        var users = await _userRepository.GetAsync();
        var eligibleUsers = users
            .Where(u => u.SendReminders && !string.IsNullOrWhiteSpace(u.PhoneNumber))
            .ToList();

        logger.LogInformation($"Found {eligibleUsers.Count} users to remind.");

        foreach (var user in eligibleUsers)
        {
            if (user.TelegramChatId is null)
            {
                logger.LogWarning($"User {user.UserName} has no TelegramChatId, skipping.");
                continue;
            }

            try
            {
                await _telegramBot.SendTextMessageAsync(
                    chatId: user.TelegramChatId,
                    text: $"👋 Hey {user.UserName}, don't forget to learn a language this week!",
                    cancellationToken: CancellationToken.None
                );

                logger.LogInformation($"Reminder sent to {user.UserName}.");
            }
            catch (Exception ex)
            {
                logger.LogError(ex, $"Failed to send reminder to {user.UserName}.");
            }
        }
    }
}