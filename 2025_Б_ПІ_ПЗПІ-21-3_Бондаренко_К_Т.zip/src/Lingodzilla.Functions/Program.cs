using Lingodzilla.Abstractions.Persistence;
using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Persistence;
using Lingodzilla.Persistence.Repositories;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

var builder = FunctionsApplication.CreateBuilder(args);

builder.ConfigureFunctionsWebApplication();

builder.Services
    .AddApplicationInsightsTelemetryWorkerService()
    .ConfigureFunctionsApplicationInsights();

builder.Services.ConfigurePersistenceDependencies(builder.Configuration);

builder.Build().Run();
