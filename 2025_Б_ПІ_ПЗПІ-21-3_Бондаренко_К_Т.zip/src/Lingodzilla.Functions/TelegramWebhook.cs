using System.Net;
using System.Text;
using Lingodzilla.Abstractions.Persistence;
using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Domain.Entities;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Newtonsoft.Json;
using Telegram.Bot;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
using Telegram.Bot.Types.ReplyMarkups;

namespace Lingodzilla.Functions;

public class TelegramWebhook
{
    private enum BotState
    {
        AwaitingPhone,
        AwaitingConfirmation,
        ShowingFlashcards
    }

    private static readonly Dictionary<long, BotState> UserState = new();

    private readonly IUnitOfWork _unitOfWork;
    private readonly IUserRepository _userRepository;
    private readonly TelegramBotClient _telegramBot;
    
    public TelegramWebhook(
        IUnitOfWork unitOfWork, 
        IUserRepository userRepository)
    {
        _unitOfWork = unitOfWork;
        _userRepository = userRepository;
        var token = Environment.GetEnvironmentVariable("TelegramBotToken")!;
        _telegramBot = new TelegramBotClient(token);
    }

    [Function(nameof(TelegramWebhook))]
    public async Task<HttpResponseData> Run(
    [HttpTrigger(AuthorizationLevel.Anonymous, "post")] HttpRequestData req,
    FunctionContext executionContext)
    {
        var body = await new StreamReader(req.Body).ReadToEndAsync();
        var update = JsonConvert.DeserializeObject<Update>(body);

        if (update?.Message == null)
            return req.CreateResponse(HttpStatusCode.OK);

        var chatId = update.Message.Chat.Id;
        var messageText = update.Message.Text?.Trim().ToLower();

        if (!UserState.TryGetValue(chatId, out var state))
        {
            UserState[chatId] = BotState.AwaitingPhone;

            var keyboard = new ReplyKeyboardMarkup([
                KeyboardButton.WithRequestContact("📱 Share your phone number")
            ])
            {
                ResizeKeyboard = true,
                OneTimeKeyboard = true
            };

            await _telegramBot.SendTextMessageAsync(
                chatId,
                "Welcome! Please share your phone number to continue.",
                replyMarkup: keyboard
            );

            return req.CreateResponse(HttpStatusCode.OK);
        }

        if (update.Message.Contact is not null && state == BotState.AwaitingPhone)
        {
            var phone = update.Message.Contact.PhoneNumber;
            var user = await _userRepository.GetByPhoneNumberAsync(phone);

            if (user is null)
            {
                await _telegramBot.SendTextMessageAsync(chatId, "User not found. Try again.");
                return req.CreateResponse(HttpStatusCode.OK);
            }

            user.TelegramChatId = chatId;
            _userRepository.Update(user);
            await _unitOfWork.SaveChangesAsync();

            UserState[chatId] = BotState.AwaitingConfirmation;

            var options = new ReplyKeyboardMarkup([
                new KeyboardButton[] { "✅ YES", "❌ NO" }
            ])
            {
                ResizeKeyboard = true
            };

            await _telegramBot.SendTextMessageAsync(
                chatId,
                $"Hi {user.UserName}! Do you want to view your flashcards?",
                replyMarkup: options
            );

            return req.CreateResponse(HttpStatusCode.OK);
        }

        if (state is BotState.AwaitingConfirmation || state is BotState.ShowingFlashcards)
        {
            if (messageText == "✅ yes" || messageText == "yes")
            {
                UserState[chatId] = BotState.ShowingFlashcards;
                await StartFlashcardSession(chatId);
                return req.CreateResponse(HttpStatusCode.OK);
            }
            else if (messageText == "❌ no" || messageText == "no")
            {
                await _telegramBot.SendTextMessageAsync(chatId, "Okay, you can type YES anytime to start reviewing flashcards.");
                return req.CreateResponse(HttpStatusCode.OK);
            }
        }

        return req.CreateResponse(HttpStatusCode.OK);
    }

    private static string FormatFlashcard(Flashcard card)
    {
        var sb = new StringBuilder();
        sb.AppendLine($"📘 *{card.Word.Text}*");
        sb.AppendLine($"Translation: {card.Word.Translation}");
        if (!string.IsNullOrWhiteSpace(card.Word.ExampleSentence))
        {
            sb.AppendLine($"Example: {card.Word.ExampleSentence}");
        }
        if (!string.IsNullOrWhiteSpace(card.Word.PartOfSpeech))
        {
            sb.AppendLine($"Part of speech: {card.Word.PartOfSpeech}");
        }
        return sb.ToString();
    }

    private async Task StartFlashcardSession(long chatId)
    {
        var user = await _userRepository.GetByTelegramChatIdAsync(chatId);
        if (user == null)
        {
            await _telegramBot.SendTextMessageAsync(chatId, "User not recognized. Please share your phone number again.");
            UserState[chatId] = BotState.AwaitingPhone;
            return;
        }

        var flashcards = (await _unitOfWork
            .GetRepository<IFlashcardRepository>()
            .GetByUserAsync(user.Id, null, null, CancellationToken.None)).ToList();

        if (flashcards.Count == 0)
        {
            await _telegramBot.SendTextMessageAsync(chatId, "You have no flashcards.");
            return;
        }

        foreach (var card in flashcards)
        {
            await _telegramBot.SendTextMessageAsync(chatId, FormatFlashcard(card), parseMode: ParseMode.Markdown);
        }

        await _telegramBot.SendTextMessageAsync(chatId, "No more flashcards. Type YES to view again.");
        UserState[chatId] = BotState.AwaitingConfirmation;
    }
}