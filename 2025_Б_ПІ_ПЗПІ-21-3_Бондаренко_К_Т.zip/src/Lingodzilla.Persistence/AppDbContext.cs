﻿using Lingodzilla.Domain.Entities;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Lingodzilla.Persistence;

public class AppDbContext : IdentityDbContext<User, Role, Guid>
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(AppDbContext).Assembly);
        base.OnModelCreating(modelBuilder);
    }

    public DbSet<Language> Languages { get; init; }
    public DbSet<Course> Courses { get; init; }
    public DbSet<Lesson> Lessons { get; init; }
    public DbSet<Exercise> Exercises { get; init; }
    public DbSet<UserProgress> UserProgresses { get; init; }
    public DbSet<Topic> Topics { get; init; }
    public DbSet<ExerciseType> ExerciseTypes { get; init; }
    public DbSet<FriendRequest> FriendRequests { get; init; }
    public DbSet<UserExerciseAttempt> UserExerciseAttempts { get; init; }
    public DbSet<UserExerciseProgress> UserExerciseProgresses { get; init; }
    public DbSet<UserLessonProgress> UserLessonProgresses { get; init; }
    public DbSet<Flashcard> Flashcards { get; init; }
    public DbSet<Word> Words { get; init; }
    public DbSet<ExerciseOption> ExerciseOptions { get; init; }
}