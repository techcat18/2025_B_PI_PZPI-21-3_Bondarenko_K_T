﻿using Lingodzilla.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Lingodzilla.Persistence.EntityConfigurations;

public class FriendRequestEntityConfiguration : IEntityTypeConfiguration<FriendRequest>
{
    public void Configure(EntityTypeBuilder<FriendRequest> builder)
    {
        builder.HasKey(x => x.Id);
        
        builder
            .HasOne(fr => fr.Requester)
            .WithMany(u => u.SentFriendRequests)
            .HasForeignKey(fr => fr.RequesterId)
            .OnDelete(DeleteBehavior.Restrict);

        builder
            .HasOne(fr => fr.Addressee)
            .WithMany(u => u.ReceivedFriendRequests)
            .HasForeignKey(fr => fr.AddresseeId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}