﻿using Lingodzilla.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Lingodzilla.Persistence.EntityConfigurations;

public class UserPreferencesEntityConfiguration : IEntityTypeConfiguration<UserPreferences>
{
    public void Configure(EntityTypeBuilder<UserPreferences> builder)
    {
        builder.HasKey(x => x.UserId);

        builder
            .HasOne(x => x.User)
            .WithOne(x => x.Preferences);

        builder
            .HasMany(x => x.PreferredExerciseTypes)
            .WithMany()
            .UsingEntity<UserPreferenceExerciseTypes>();

        builder
            .HasMany(x => x.PreferredTopics)
            .WithMany()
            .UsingEntity<UserPreferenceTopics>();
    }
}