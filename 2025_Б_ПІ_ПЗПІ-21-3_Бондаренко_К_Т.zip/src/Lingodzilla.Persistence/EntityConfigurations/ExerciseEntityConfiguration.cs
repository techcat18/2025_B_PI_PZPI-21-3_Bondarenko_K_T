﻿using Lingodzilla.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Lingodzilla.Persistence.EntityConfigurations;

public class ExerciseEntityConfiguration : IEntityTypeConfiguration<Exercise>
{
    public void Configure(EntityTypeBuilder<Exercise> builder)
    {
        builder.Property(x => x.Id);

        builder
            .HasMany(e => e.Words)
            .WithMany(w => w.Exercises)
            .UsingEntity<ExerciseWord>(
                join => join
                    .HasOne(ew => ew.Word)
                    .WithMany()
                    .HasForeignKey(ew => ew.WordId)
                    .OnDelete(DeleteBehavior.Cascade),

                join => join
                    .HasOne(ew => ew.Exercise)
                    .WithMany()
                    .HasForeignKey(ew => ew.ExerciseId)
                    .OnDelete(DeleteBehavior.Cascade),

                join =>
                {
                    join.HasKey(ew => new { ew.ExerciseId, ew.WordId });
                    join.ToTable("ExerciseWords");
                });
    }
}