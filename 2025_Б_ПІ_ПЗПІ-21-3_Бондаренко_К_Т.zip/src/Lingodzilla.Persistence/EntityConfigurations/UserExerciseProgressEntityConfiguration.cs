﻿using Lingodzilla.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Lingodzilla.Persistence.EntityConfigurations;

public class UserExerciseProgressEntityConfiguration : IEntityTypeConfiguration<UserExerciseProgress>
{
    public void Configure(EntityTypeBuilder<UserExerciseProgress> builder)
    {
        builder.HasKey(x => x.Id);
    }
}