﻿using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Persistence.Extensions;

public static class FlashcardExtensions
{
    public static IQueryable<Flashcard> FilterBySearchQuery(
        this IQueryable<Flashcard> query,
        string? searchQuery)
    {
        if (!string.IsNullOrWhiteSpace(searchQuery))
        {
            searchQuery = searchQuery.Trim().ToLower();
            query = query.Where(x => x.Word.Text.ToLower().Contains(searchQuery));
        }

        return query;
    }
    
    public static IQueryable<Flashcard> FilterByIsActive(
        this IQueryable<Flashcard> query,
        bool? isActive)
    {
        if (isActive is not null && isActive.Value)
        {
            query = query.Where(x => x.IsActive == isActive);
        }

        return query;
    }
}