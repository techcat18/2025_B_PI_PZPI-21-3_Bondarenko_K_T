﻿using Lingodzilla.Abstractions.Persistence;
using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Common.Constants;
using Lingodzilla.Domain.Entities;
using Lingodzilla.Persistence.Repositories;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Lingodzilla.Persistence;

public static class DependencyRegistrar
{
    public static void ConfigurePersistenceDependencies(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        var sqlConnectionString = configuration.GetConnectionString(ConfigurationNames.SqlConnectionString);
        services.AddDbContext<AppDbContext>(options =>
        {
            options.UseSqlServer(sqlConnectionString);
        });

        services.AddScoped<ILanguageRepository, LanguageRepository>();
        services.AddScoped<ICourseRepository, CourseRepository>();
        services.AddScoped<ILessonRepository, LessonRepository>();
        services.AddScoped<IExerciseRepository, ExerciseRepository>();
        services.AddScoped<IUserProgressRepository, UserProgressRepository>();
        services.AddScoped<ITopicRepository, TopicRepository>();
        services.AddScoped<IUnitOfWork, UnitOfWork>();
        services.AddScoped<IExerciseTypeRepository, ExerciseTypeRepository>();
        services.AddScoped<IUserExerciseAttemptRepository, UserExerciseAttemptRepository>();
        services.AddScoped<IUserExerciseProgressRepository, UserExerciseProgressRepository>();
        services.AddScoped<IUserLessonProgressRepository, UserLessonProgressRepository>();
        services.AddScoped<IUserRepository, UserRepository>();
        services.AddScoped<IFriendRequestRepository, FriendRequestRepository>();
        services.AddScoped<IFlashcardRepository, FlashcardRepository>();
        services.AddScoped<IWordRepository, WordRepository>();
        
        services.ConfigureIdentity();
    }
    
    private static void ConfigureIdentity(
        this IServiceCollection services)
    {
        services
            .AddIdentity<User, Role>(opt =>
            {
                opt.Password.RequiredLength = 8;
                opt.Password.RequireLowercase = false;
                opt.Password.RequireUppercase = true;
                opt.Password.RequireDigit = true;
                opt.Password.RequireNonAlphanumeric = false;
                opt.User.RequireUniqueEmail = true;
                opt.SignIn.RequireConfirmedEmail = false;
            })
            .AddEntityFrameworkStores<AppDbContext>()
            .AddDefaultTokenProviders();
    }
}