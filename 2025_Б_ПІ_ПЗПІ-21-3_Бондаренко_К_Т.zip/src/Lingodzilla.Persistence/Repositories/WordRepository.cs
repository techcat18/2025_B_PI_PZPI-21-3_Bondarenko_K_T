﻿using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Persistence.Repositories;

public class WordRepository : GenericRepository<Word>, IWordRepository
{
    public WordRepository(AppDbContext context) : base(context)
    {
    }
}