﻿using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Lingodzilla.Persistence.Repositories;

public class UserExerciseAttemptRepository : GenericRepository<UserExerciseAttempt>, IUserExerciseAttemptRepository
{
    public UserExerciseAttemptRepository(AppDbContext context) : base(context)
    {
    }

    public async Task<IEnumerable<UserExerciseAttempt>> GetAsync(
        Guid userId, 
        Guid exerciseId, 
        CancellationToken cancellationToken = default)
    {
        return await DbSet
            .Where(x => x.UserId == userId && x.ExerciseId == exerciseId)
            .Include(x => x.User)
            .Include(x => x.Exercise)
            .ToListAsync(cancellationToken);
    }
}