﻿using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Domain.Entities;
using Lingodzilla.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace Lingodzilla.Persistence.Repositories;

public class FriendRequestRepository : GenericRepository<FriendRequest>, IFriendRequestRepository
{
    public FriendRequestRepository(AppDbContext context) : base(context)
    {
    }

    public async Task<IEnumerable<FriendRequest>> GetPendingByAddresseeIdAsync(
        Guid addresseeId, 
        CancellationToken cancellationToken = default)
    {
        return await DbSet
            .Where(x => x.AddresseeId == addresseeId && x.Status == FriendRequestStatus.Pending)
            .Include(x => x.Requester)
            .Include(x => x.Addressee)
            .ToListAsync(cancellationToken);
    }

    public async Task<FriendRequest?> GetByRequesterAndAddresseeIdsAsync(
        Guid requesterId, 
        Guid addresseeId,
        CancellationToken cancellationToken = default)
    {
        return await DbSet
            .FirstOrDefaultAsync(x => (x.RequesterId == requesterId && x.AddresseeId == addresseeId) ||
                                      (x.AddresseeId == requesterId && x.RequesterId == addresseeId),
                cancellationToken);
    }
}