﻿using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Lingodzilla.Persistence.Repositories;

public class UserLessonProgressRepository : GenericRepository<UserLessonProgress>, IUserLessonProgressRepository
{
    public UserLessonProgressRepository(AppDbContext context) : base(context)
    {
    }

    public async Task<UserLessonProgress?> FindAsync(
        Guid userId, 
        Guid lessonId, 
        CancellationToken cancellationToken = default)
    {
        return await DbSet
            .Include(x => x.User)
            .Include(x => x.Lesson)
            .FirstOrDefaultAsync(x => x.UserId == userId && x.LessonId == lessonId, cancellationToken);
    }
}