﻿using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Domain.Entities;
using Lingodzilla.Persistence.Extensions;
using Microsoft.EntityFrameworkCore;

namespace Lingodzilla.Persistence.Repositories;

public class FlashcardRepository : GenericRepository<Flashcard>, IFlashcardRepository
{
    public FlashcardRepository(AppDbContext context) : base(context)
    {
    }

    public async Task<IEnumerable<Flashcard>> GetByUserAsync(
        Guid userId, 
        string? searchQuery,
        bool? isActive,
        CancellationToken cancellationToken = default)
    {
        return await DbSet
            .Include(x => x.User)
            .Include(x => x.Word)
            .Include(x => x.Exercise)
            .FilterBySearchQuery(searchQuery)
            .FilterByIsActive(isActive)
            .Where(x => x.UserId == userId)
            .ToListAsync(cancellationToken);
    }

    public async Task<IEnumerable<Flashcard>> GetByUserAndExerciseAsync(
        Guid userId, 
        Guid exerciseId, 
        CancellationToken cancellationToken = default)
    {
        return await DbSet
            .Include(x => x.User)
            .Include(x => x.Word)
            .Include(x => x.Exercise)
            .Where(x => x.UserId == userId && x.ExerciseId == exerciseId)
            .ToListAsync(cancellationToken);
    }
}