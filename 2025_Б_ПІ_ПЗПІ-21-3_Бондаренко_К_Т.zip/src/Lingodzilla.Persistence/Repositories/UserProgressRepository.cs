﻿using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Persistence.Repositories;

public class UserProgressRepository : GenericRepository<UserProgress>, IUserProgressRepository
{
    public UserProgressRepository(AppDbContext context) : base(context)
    {
    }
}