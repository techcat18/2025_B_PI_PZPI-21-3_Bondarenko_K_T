﻿using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Lingodzilla.Persistence.Repositories;

public class ExerciseRepository : GenericRepository<Exercise>, IExerciseRepository
{
    public ExerciseRepository(AppDbContext context) : base(context)
    {
    }

    public async Task<IEnumerable<Exercise>> GetByLessonIdAsync(
        Guid lessonId, 
        CancellationToken cancellationToken = default)
    {
        return await DbSet
            .Include(x => x.ExerciseType)
            .Include(x => x.Words)
            .Include(x => x.Options)
            .Where(x => x.LessonId == lessonId)
            .ToListAsync(cancellationToken);
    } 
    
    public override async Task<Exercise?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        return await DbSet
            .Include(x => x.ExerciseType)
            .Include(x => x.Lesson)
            .Include(x => x.Options)
            .Include(x => x.Words)
            .ThenInclude(x => x.Exercises)
            .FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
    }
}