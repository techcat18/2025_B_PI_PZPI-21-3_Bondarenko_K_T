﻿using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Persistence.Repositories;

public class ExerciseTypeRepository : GenericRepository<ExerciseType>, IExerciseTypeRepository
{
    public ExerciseTypeRepository(AppDbContext context) : base(context)
    {
    }
}