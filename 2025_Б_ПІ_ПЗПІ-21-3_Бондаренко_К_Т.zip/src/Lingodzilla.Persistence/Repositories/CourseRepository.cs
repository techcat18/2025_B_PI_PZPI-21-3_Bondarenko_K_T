﻿using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Lingodzilla.Persistence.Repositories;

public class CourseRepository : GenericRepository<Course>, ICourseRepository
{
    public CourseRepository(AppDbContext context) : base(context)
    {
    }

    public override async Task<List<Course>> GetAllAsync(CancellationToken cancellationToken = default)
    {
        return await DbSet
            .Include(x => x.Language)
            .Include(x => x.TargetLanguage)
            .Include(x => x.User)
            .ToListAsync(cancellationToken);
    }

    public override async Task<Course?> GetByIdAsync(Guid id, CancellationToken cancellationToken = default)
    {
        return await DbSet
            .Include(x => x.Language)
            .Include(x => x.TargetLanguage)
            .Include(x => x.User)
            .FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
    }

    public async Task<IEnumerable<Course>> GetCoursesByUserAsync(
        Guid id, 
        CancellationToken cancellationToken = default)
    {
        return await DbSet
            .Include(x => x.Language)
            .Include(x => x.TargetLanguage)
            .Include(x => x.User)
            .Where(x => x.UserId == null || x.UserId == id)
            .ToListAsync(cancellationToken);
    }
}