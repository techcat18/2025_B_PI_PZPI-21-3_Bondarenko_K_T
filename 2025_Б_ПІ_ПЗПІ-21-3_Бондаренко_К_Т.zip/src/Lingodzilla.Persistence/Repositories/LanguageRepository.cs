﻿using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Domain.Entities;

namespace Lingodzilla.Persistence.Repositories;

public class LanguageRepository : GenericRepository<Language>, ILanguageRepository
{
    public LanguageRepository(AppDbContext context) : base(context)
    {
    }
}