﻿using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Domain.Entities;
using Lingodzilla.Domain.Enums;
using Microsoft.EntityFrameworkCore;

namespace Lingodzilla.Persistence.Repositories;

public class UserRepository : IUserRepository
{
    private readonly AppDbContext _context;

    public UserRepository(AppDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<User>> GetAsync(
        CancellationToken cancellationToken = default)
    {
        return await _context
            .Set<User>()
            .ToListAsync(cancellationToken);
    }

    public async Task<IEnumerable<User>> GetFriendsAsync(
        Guid userId,
        CancellationToken cancellationToken = default)
    {
        return await _context.FriendRequests
            .Where(fr => (fr.RequesterId == userId || fr.AddresseeId == userId) && fr.Status == FriendRequestStatus.Accepted)
            .Select(fr => fr.RequesterId == userId ? fr.Addressee : fr.Requester)
            .ToListAsync(cancellationToken);
    }
    
    public async Task<User?> GetByIdAsync(
        Guid id, 
        CancellationToken cancellationToken = default)
    {
        return await _context
            .Set<User>()
            .FirstOrDefaultAsync(x => x.Id == id, cancellationToken);
    }

    public async Task<User?> GetByPhoneNumberAsync(
        string phoneNumber, 
        CancellationToken cancellationToken = default)
    {
        return await _context
            .Set<User>()
            .FirstOrDefaultAsync(x => x.PhoneNumber == phoneNumber, cancellationToken);    }

    public async Task<User?> GetByTelegramChatIdAsync(
        long telegramChatId, 
        CancellationToken cancellationToken = default)
    {
        return await _context
            .Set<User>()
            .FirstOrDefaultAsync(x => x.TelegramChatId == telegramChatId, cancellationToken);
    }

    public async Task<List<LeaderboardEntry>> GetCompletedExercisesLeaderboardAsync(
        int limit, 
        CancellationToken cancellationToken = default)
    {
        return await _context
            .Set<User>()
            .Include(x => x.ExerciseProgresses)
            .Select(u => new LeaderboardEntry
            {
                User = u,
                Score = u.ExerciseProgresses.Count(p => p.IsCompleted)
            })
            .OrderByDescending(x => x.Score)
            .Take(limit)
            .ToListAsync(cancellationToken);
    }

    public async Task<List<LeaderboardEntry>> GetCorrectAnswersLeaderboardAsync(
        int limit, 
        CancellationToken cancellationToken = default)
    {
        return await _context
            .Set<User>()
            .Include(x => x.ExerciseAttempts)
            .Select(u => new LeaderboardEntry
            {
                User = u,
                Score = u.ExerciseAttempts.Count(a => a.IsCorrect)
            })
            .OrderByDescending(x => x.Score)
            .Take(limit)
            .ToListAsync(cancellationToken);
    }

    public async Task<List<LeaderboardEntry>> GetAccuracyLeaderboardAsync(
        int limit, 
        CancellationToken cancellationToken = default)
    {
        return await _context
            .Set<User>()
            .Where(u => u.ExerciseAttempts.Any())
            .Include(x => x.ExerciseAttempts)
            .Select(u => new LeaderboardEntry
            {
                User = u,
                Score = u.ExerciseAttempts.Count(a => a.IsCorrect) * 1.0 / u.ExerciseAttempts.Count()
            })
            .OrderByDescending(x => x.Score)
            .Take(limit)
            .ToListAsync(cancellationToken);
    }

    public async Task<List<LeaderboardEntry>> GetCompletedLessonsLeaderboardAsync(
        int limit, 
        CancellationToken cancellationToken = default)
    {
        return await _context
            .Set<User>()
            .Include(x => x.LessonProgresses)
            .Select(u => new LeaderboardEntry
            {
                User = u,
                Score = u.LessonProgresses.Count(p => p.IsCompleted)
            })
            .OrderByDescending(x => x.Score)
            .Take(limit)
            .ToListAsync(cancellationToken);
    }

    public void Update(User user)
    {
        _context.Set<User>().Update(user);
    }

    public async Task SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        await _context.SaveChangesAsync(cancellationToken);
    }
}