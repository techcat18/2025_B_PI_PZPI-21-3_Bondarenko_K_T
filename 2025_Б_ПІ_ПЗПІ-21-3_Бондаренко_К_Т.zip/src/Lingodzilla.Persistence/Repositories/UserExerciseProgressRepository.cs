﻿using Lingodzilla.Abstractions.Persistence.Repositories;
using Lingodzilla.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Lingodzilla.Persistence.Repositories;

public class UserExerciseProgressRepository : GenericRepository<UserExerciseProgress>, IUserExerciseProgressRepository
{
    public UserExerciseProgressRepository(AppDbContext context) : base(context)
    {
    }

    public async Task<IEnumerable<UserExerciseProgress>> GetCompletedAsync(
        Guid userId, 
        List<Guid> exerciseIds, 
        CancellationToken cancellationToken = default)
    {
        return await DbSet
            .Include(x => x.User)
            .Include(x => x.Exercise)
            .Where(x => x.UserId == userId && exerciseIds.Contains(x.ExerciseId) && x.IsCompleted)
            .ToListAsync(cancellationToken);
    }

    public async Task<UserExerciseProgress?> FindAsync(Guid userId, Guid exerciseId, CancellationToken cancellationToken = default)
    {
        return await DbSet
            .Include(x => x.User)
            .Include(x => x.Exercise)
            .FirstOrDefaultAsync(x => x.UserId == userId && x.ExerciseId == exerciseId, cancellationToken);
    }
}